# RPMS Web

Frontend Next.js 15 (App Router, RSC, TypeScript strict).

## Requisitos

- Node.js ≥ 20
- pnpm 9 (recomendado) o npm

## Instalación y desarrollo

```bash
cd frontend/web
pnpm install     # o `npm install`
pnpm dev         # abre http://localhost:3000
```

## Estructura

```
src/
├── app/                      # App Router
│   ├── layout.tsx            # Layout raíz con sidebar + topbar
│   ├── page.tsx              # Dashboard ejecutivo (§9 blueprint)
│   ├── globals.css           # Design tokens (light + dark)
│   └── workers/
│       ├── page.tsx          # Lista de trabajadores
│       └── [id]/page.tsx     # Ficha del trabajador (§8.3.1 blueprint)
├── components/
│   ├── layout/               # Sidebar, Topbar
│   ├── dashboard/            # KPI cards, gráficos, alertas, copilot
│   └── search/               # Command bar universal (⌘K)
└── lib/
    └── utils.ts              # cn(), formatMSv(), formatDate()
```

## Design system

- Colores: acento único (azul RPMS `#3B82F6`) + neutrales cálidos + semánticos.
- Tipografía: Inter (UI) + JetBrains Mono (datos numéricos).
- Modo oscuro como primer ciudadano; light se adapta.
- Densidad: cómodo por defecto; compacto disponible.
- Accesibilidad: WCAG 2.2 AA verificado con axe-core en CI.

## Testing

```bash
pnpm test         # Vitest unit + component
pnpm test:e2e     # Playwright end-to-end
pnpm typecheck    # TypeScript strict check
```

## Referencias

- Blueprint arquitectónico: `../../docs/architecture/RPMS_Arquitectura_Completa.md`
- Contratos OpenAPI: `../../docs/api/openapi.yaml`
