"use client";

import { Bell, Bot, Search } from "lucide-react";
import { useState } from "react";
import { CommandBar } from "@/components/search/command-bar";

export function Topbar() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border bg-surface/80 px-4 backdrop-blur">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="group flex h-9 flex-1 max-w-md items-center gap-2 rounded-md border border-border bg-background px-2.5 text-sm text-muted-foreground transition-colors hover:border-accent"
        >
          <Search className="h-4 w-4" strokeWidth={2} />
          <span>Buscar trabajadores, equipos, documentos…</span>
          <kbd className="ml-auto rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[10px]">
            ⌘K
          </kbd>
        </button>

        <button
          type="button"
          className="relative rounded-md p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          aria-label="Notificaciones"
        >
          <Bell className="h-4 w-4" strokeWidth={2} />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-danger" />
        </button>

        <button
          type="button"
          className="flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1.5 text-xs font-medium text-foreground hover:border-accent"
        >
          <Bot className="h-3.5 w-3.5" strokeWidth={2} />
          Copilot
          <kbd className="rounded border border-border bg-muted px-1 py-0.5 font-mono text-[10px]">
            ⌥·
          </kbd>
        </button>
      </header>
      <CommandBar open={open} onOpenChange={setOpen} />
    </>
  );
}
