import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface KPICardProps {
  label: string;
  value: number | string;
  href: string;
  icon: LucideIcon;
  tone?: "default" | "success" | "warning" | "danger" | "info";
  trend?: {
    direction: "up" | "down" | "neutral";
    label: string;
  };
}

const TONE: Record<NonNullable<KPICardProps["tone"]>, string> = {
  default: "text-foreground",
  success: "text-success",
  warning: "text-warning",
  danger: "text-danger",
  info: "text-info",
};

export function KPICard({ label, value, href, icon: Icon, tone = "default", trend }: KPICardProps) {
  return (
    <Link
      href={href}
      className="group flex flex-col justify-between rounded-lg border border-border bg-surface p-3 shadow-subtle transition-all hover:border-accent hover:shadow-card"
    >
      <div className="flex items-start justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
        <Icon className={cn("h-3.5 w-3.5", TONE[tone])} strokeWidth={2} />
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className={cn("text-2xl font-semibold tabular-nums", TONE[tone])}>
          {value}
        </span>
        {trend && (
          <span className={cn(
            "text-[10px] font-medium",
            trend.direction === "up" && "text-warning",
            trend.direction === "down" && "text-success",
            trend.direction === "neutral" && "text-muted-foreground",
          )}>
            {trend.direction === "up" ? "↑" : trend.direction === "down" ? "↓" : "→"} {trend.label}
          </span>
        )}
      </div>
    </Link>
  );
}
