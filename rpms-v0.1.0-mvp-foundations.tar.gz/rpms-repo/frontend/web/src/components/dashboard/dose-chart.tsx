"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface DataPoint {
  month: string;
  radiotherapy: number;
  nuclearMedicine: number;
  imaging: number;
  interventional: number;
}

const DATA: DataPoint[] = [
  { month: "Ago 25", radiotherapy: 1.2, nuclearMedicine: 2.1, imaging: 0.8, interventional: 1.5 },
  { month: "Sep 25", radiotherapy: 1.4, nuclearMedicine: 2.3, imaging: 0.9, interventional: 1.6 },
  { month: "Oct 25", radiotherapy: 1.1, nuclearMedicine: 2.0, imaging: 0.7, interventional: 1.4 },
  { month: "Nov 25", radiotherapy: 1.3, nuclearMedicine: 2.2, imaging: 0.8, interventional: 1.5 },
  { month: "Dic 25", radiotherapy: 1.5, nuclearMedicine: 2.4, imaging: 0.9, interventional: 1.7 },
  { month: "Ene 26", radiotherapy: 1.2, nuclearMedicine: 2.1, imaging: 0.8, interventional: 1.5 },
  { month: "Feb 26", radiotherapy: 1.3, nuclearMedicine: 2.3, imaging: 0.8, interventional: 1.4 },
  { month: "Mar 26", radiotherapy: 1.4, nuclearMedicine: 2.2, imaging: 0.9, interventional: 1.6 },
  { month: "Abr 26", radiotherapy: 1.1, nuclearMedicine: 2.0, imaging: 0.7, interventional: 1.5 },
  { month: "May 26", radiotherapy: 1.3, nuclearMedicine: 2.4, imaging: 0.8, interventional: 1.6 },
  { month: "Jun 26", radiotherapy: 1.5, nuclearMedicine: 2.6, imaging: 0.9, interventional: 1.8 },
  { month: "Jul 26", radiotherapy: 1.2, nuclearMedicine: 2.3, imaging: 0.8, interventional: 1.5 },
];

const SERIES: Array<{ key: keyof Omit<DataPoint, "month">; label: string; color: string }> = [
  { key: "radiotherapy", label: "Radioterapia", color: "hsl(217 91% 60%)" },
  { key: "nuclearMedicine", label: "Medicina Nuclear", color: "hsl(158 76% 46%)" },
  { key: "imaging", label: "Imagenología", color: "hsl(38 92% 60%)" },
  { key: "interventional", label: "Intervencionismo", color: "hsl(280 65% 60%)" },
];

export function DoseChart() {
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-4">
        {SERIES.map((s) => (
          <div key={s.key} className="flex items-center gap-1.5">
            <span
              className="h-2 w-2 rounded-sm"
              style={{ backgroundColor: s.color }}
            />
            <span className="text-[10px] text-muted-foreground">{s.label}</span>
          </div>
        ))}
      </div>
      <div className="h-[220px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={DATA} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
            <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="0" vertical={false} />
            <XAxis
              dataKey="month"
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => `${v} mSv`}
            />
            <Tooltip
              cursor={{ fill: "hsl(var(--muted))" }}
              contentStyle={{
                backgroundColor: "hsl(var(--surface-overlay))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                fontSize: "11px",
              }}
            />
            {SERIES.map((s) => (
              <Bar key={s.key} dataKey={s.key} stackId="dose" fill={s.color} radius={[0, 0, 0, 0]}>
                {DATA.map((_, i) => (
                  <Cell key={i} />
                ))}
              </Bar>
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
