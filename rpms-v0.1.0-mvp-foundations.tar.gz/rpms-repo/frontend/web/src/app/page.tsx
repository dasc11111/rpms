import {
  Activity,
  AlertTriangle,
  Ban,
  Calendar,
  ClipboardCheck,
  FileWarning,
  Package,
  PauseCircle,
  Radio,
  Radiation,
  Search,
  ShieldAlert,
  UserCog,
  Users,
  Wrench,
  XCircle,
} from "lucide-react";
import { KPICard } from "@/components/dashboard/kpi-card";
import { DoseChart } from "@/components/dashboard/dose-chart";
import { AlertsPanel } from "@/components/dashboard/alerts-panel";
import { CopilotSuggestions } from "@/components/dashboard/copilot-suggestions";

/**
 * Dashboard ejecutivo — sección 9 del blueprint arquitectónico.
 * En una pantalla y sin scroll (1440x900), 90% de la información crítica en 3s.
 */
export default function Dashboard() {
  const now = new Date().toLocaleString("es-CL", {
    dateStyle: "long",
    timeStyle: "short",
  });

  return (
    <div className="mx-auto max-w-[1400px] p-6">
      {/* Encabezado */}
      <div className="mb-4 flex items-baseline justify-between">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">
            Buenos días, Javiera.
          </h1>
          <p className="text-xs text-muted-foreground">
            Estado a {now}
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="rounded-md bg-success-subtle px-2 py-1 font-medium text-success">
            ✓ Sistema operativo
          </span>
        </div>
      </div>

      {/* Grilla KPIs — 2 filas × 6 columnas = 12 KPIs (blueprint §9.2) */}
      <div className="mb-4 grid grid-cols-3 gap-2 md:grid-cols-4 lg:grid-cols-6">
        <KPICard label="Trabajadores activos" value={218} href="/workers?status=active" icon={Users} />
        <KPICard label="Suspendidos" value={4} href="/workers?status=suspended" icon={PauseCircle} tone="warning" />
        <KPICard label="Dosím. pend. devolver" value={7} href="/dosimetry/dosimeters?status=not_returned" icon={Package} tone="warning" />
        <KPICard label="Dosím. extraviados" value={2} href="/dosimetry/dosimeters?status=lost" icon={Search} tone="danger" />
        <KPICard label="Sin autorización" value={3} href="/workers?filter=missing_authorization" icon={XCircle} tone="danger" />
        <KPICard label="Autoriz. próx. vencer" value={12} href="/workers?filter=authorization_expiring" icon={UserCog} tone="warning" />

        <KPICard label="Equipos pendientes" value={5} href="/equipment?status=pending" icon={Radio} />
        <KPICard label="Equipos fuera servicio" value={2} href="/equipment?status=out_of_service" icon={Ban} tone="warning" />
        <KPICard label="Blindajes pendientes" value={1} href="/shielding?status=pending" icon={ShieldAlert} tone="warning" />
        <KPICard label="QA pendientes" value={8} href="/equipment/qa?status=pending" icon={ClipboardCheck} tone="warning" />
        <KPICard label="Inspecciones pendientes" value={4} href="/audits?status=pending" icon={FileWarning} tone="warning" />
        <KPICard label="Incidentes abiertos" value={3} href="/incidents?status=open" icon={AlertTriangle} tone="danger" />
      </div>

      {/* Fila principal: gráfico + panel vencimientos */}
      <div className="mb-4 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-surface p-4">
          <div className="mb-3 flex items-baseline justify-between">
            <div>
              <h2 className="text-sm font-semibold">Dosis colectiva mensual</h2>
              <p className="text-[11px] text-muted-foreground">Últimos 12 meses, por servicio (mSv)</p>
            </div>
            <span className="text-[10px] font-medium text-muted-foreground">Total 12m: 68.4 mSv</span>
          </div>
          <DoseChart />
        </div>

        <div className="rounded-lg border border-border bg-surface p-4">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="text-sm font-semibold">Vencimientos próximos 90 días</h2>
            <span className="text-[10px] text-muted-foreground">
              <Calendar className="mr-1 inline h-3 w-3" /> hasta 12/10/2026
            </span>
          </div>
          <div className="space-y-3">
            <ProgressRow label="Autorizaciones" value={12} total={35} tone="warning" href="/workers?filter=authorization_expiring" />
            <ProgressRow label="Licencias" value={5} total={18} tone="warning" href="/facilities?filter=license_expiring" />
            <ProgressRow label="Calibraciones" value={18} total={42} tone="danger" href="/instruments?filter=calibration_expiring" />
            <ProgressRow label="QA equipos" value={7} total={24} tone="info" href="/equipment/qa?filter=due_soon" />
            <ProgressRow label="Capacitaciones" value={9} total={31} tone="info" href="/workers/trainings?filter=due_soon" />
          </div>
        </div>
      </div>

      {/* Fila inferior: alertas regulatorias + copilot */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-surface p-4">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="text-sm font-semibold">Alertas regulatorias</h2>
            <span className="text-[10px] text-muted-foreground">4 activas</span>
          </div>
          <AlertsPanel />
        </div>

        <div className="rounded-lg border border-border bg-surface p-4">
          <div className="mb-3 flex items-baseline justify-between">
            <div className="flex items-center gap-1.5">
              <Radiation className="h-3.5 w-3.5 text-accent" strokeWidth={2} />
              <h2 className="text-sm font-semibold">Copilot — Recomendado hoy</h2>
            </div>
            <span className="text-[10px] text-muted-foreground">4 sugerencias</span>
          </div>
          <CopilotSuggestions />
        </div>
      </div>
    </div>
  );
}

// Barra de progreso semántica para vencimientos
function ProgressRow({
  label,
  value,
  total,
  tone,
  href,
}: {
  label: string;
  value: number;
  total: number;
  tone: "info" | "warning" | "danger";
  href: string;
}) {
  const pct = Math.min(100, Math.round((value / total) * 100));
  const barTone =
    tone === "danger" ? "bg-danger" : tone === "warning" ? "bg-warning" : "bg-info";
  return (
    <a href={href} className="group block">
      <div className="mb-1 flex items-baseline justify-between text-xs">
        <span className="text-foreground">{label}</span>
        <span className="tabular-nums text-muted-foreground">
          <span className="font-medium text-foreground">{value}</span> / {total}
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className={`h-full transition-all group-hover:opacity-90 ${barTone}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </a>
  );
}
