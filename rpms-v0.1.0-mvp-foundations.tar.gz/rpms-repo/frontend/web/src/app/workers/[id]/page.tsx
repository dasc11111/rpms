import Link from "next/link";
import { notFound } from "next/navigation";
import {
  Activity,
  ChevronLeft,
  ClipboardList,
  FileText,
  QrCode,
  Sparkles,
  Stethoscope,
  UserCheck,
} from "lucide-react";
import { cn, formatMSv } from "@/lib/utils";

/**
 * Ficha del trabajador — sección 8.3.1 del blueprint.
 * Tabs: Resumen · Dosimetría · Autorizaciones · Capacitaciones · Incidentes · Documentos
 */

interface Worker {
  id: string;
  fullName: string;
  nationalId: string;
  role: string;
  service: string;
  category: "A" | "B";
  status: "active" | "suspended" | "onboarding" | "terminated";
  contract: string;
  monthlyDoses: number[];
  annualDose: number;
  fiveYearDose: number;
  authorizations: Array<{ name: string; expires: string; state: "vigente" | "por_vencer" | "expirada" }>;
  nextActions: string[];
}

// Mock data — en producción viene del workforce-svc via TanStack Query
const WORKER_MOCK: Worker = {
  id: "w-1",
  fullName: "Javiera Muñoz",
  nationalId: "17.245.892-0",
  role: "Físico Médico",
  service: "Radioterapia",
  category: "A",
  status: "active",
  contract: "Indefinido",
  monthlyDoses: [0.22, 0.28, 0.24, 0.30, 0.26, 0.31, 0.29, 0.24, 0.27, 0.34, 0.28, 0.29],
  annualDose: 3.2,
  fiveYearDose: 18.4,
  authorizations: [
    { name: "Operador LINAC #4571", expires: "2027-03-15", state: "vigente" },
    { name: "OPR titular", expires: "2026-08-30", state: "por_vencer" },
  ],
  nextActions: [
    "Examen ocupacional bienal en 42 días",
    "Curso de recertificación en 7 meses",
  ],
};

export default async function WorkerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!id) return notFound();
  const worker = WORKER_MOCK;

  return (
    <div className="mx-auto max-w-[1200px] p-6">
      {/* Header */}
      <Link
        href="/workers"
        className="mb-3 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-3 w-3" />
        Trabajadores
      </Link>

      <div className="mb-4 flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-accent-subtle text-accent">
            <span className="text-lg font-semibold">JM</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-semibold tracking-tight">{worker.fullName}</h1>
              <span className="rounded-md bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                {worker.nationalId}
              </span>
            </div>
            <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
              <span>{worker.role}</span>
              <span>·</span>
              <span>{worker.service}</span>
              <span>·</span>
              <span className="rounded-md bg-info-subtle px-1.5 py-0.5 font-medium text-info">
                Categoría {worker.category} (ICRP)
              </span>
              <span>·</span>
              <StatusBadge status={worker.status} />
              <span>·</span>
              <span>{worker.contract}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="flex h-9 items-center gap-1.5 rounded-md border border-border bg-surface px-3 text-xs font-medium hover:border-accent"
          >
            <QrCode className="h-3.5 w-3.5" strokeWidth={2} />
            QR
          </button>
          <button
            type="button"
            className="flex h-9 items-center gap-1.5 rounded-md bg-accent px-3 text-xs font-medium text-accent-foreground hover:opacity-90"
          >
            Acciones
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-4 flex gap-1 border-b border-border">
        {["Resumen", "Dosimetría", "Autorizaciones", "Capacitaciones", "Incidentes", "Documentos"].map((tab, i) => (
          <button
            key={tab}
            type="button"
            className={cn(
              "border-b-2 px-3 py-1.5 text-xs font-medium",
              i === 0
                ? "border-accent text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Contenido — Tab Resumen */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Columna izquierda: dosimetría */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          {/* Dosis últimos 12m */}
          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-3 flex items-baseline justify-between">
              <div>
                <h2 className="text-sm font-semibold">Dosis Hp(10) últimos 12 meses</h2>
                <p className="text-[11px] text-muted-foreground">
                  Anual: <span className="font-medium text-foreground">{formatMSv(worker.annualDose)}</span>
                  <span className="mx-2">·</span>
                  5-anual: <span className="font-medium text-foreground">{formatMSv(worker.fiveYearDose)}</span>
                  <span className="mx-2 text-success">✓</span>
                  <span className="text-success">Bajo límite (100 mSv)</span>
                </p>
              </div>
              <Activity className="h-3.5 w-3.5 text-accent" />
            </div>
            <SparkChart values={worker.monthlyDoses} />
          </div>

          {/* Autorizaciones */}
          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-3 flex items-baseline justify-between">
              <div className="flex items-center gap-1.5">
                <UserCheck className="h-3.5 w-3.5 text-muted-foreground" />
                <h2 className="text-sm font-semibold">Autorizaciones</h2>
              </div>
            </div>
            <div className="space-y-2">
              {worker.authorizations.map((a) => (
                <div
                  key={a.name}
                  className="flex items-center justify-between rounded-md border border-border p-2.5"
                >
                  <div className="flex flex-col">
                    <span className="text-sm text-foreground">{a.name}</span>
                    <span className="text-[11px] text-muted-foreground">
                      Vence {a.expires}
                    </span>
                  </div>
                  <AuthorizationBadge state={a.state} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Columna derecha */}
        <div className="flex flex-col gap-4">
          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-3 flex items-center gap-1.5">
              <ClipboardList className="h-3.5 w-3.5 text-muted-foreground" />
              <h2 className="text-sm font-semibold">Próximas acciones</h2>
            </div>
            <ul className="space-y-1.5">
              {worker.nextActions.map((a) => (
                <li
                  key={a}
                  className="rounded-md border border-border bg-background p-2 text-xs text-foreground"
                >
                  {a}
                </li>
              ))}
            </ul>
          </div>

          {/* Copilot inline */}
          <div className="rounded-lg border border-accent-subtle bg-accent-subtle/40 p-4">
            <div className="mb-2 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-accent" />
              <h2 className="text-sm font-semibold">Copilot</h2>
            </div>
            <p className="text-xs text-foreground">
              Todo en orden. La renovación de OPR titular vence en 47 días y
              requiere curso de recertificación de 40 h. Quedan 2 cupos en el
              curso del 12/08.
            </p>
            <button
              type="button"
              className="mt-2 flex h-8 w-full items-center justify-center gap-1.5 rounded-md bg-accent text-xs font-medium text-accent-foreground hover:opacity-90"
            >
              Reservar cupo
            </button>
          </div>

          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-3 flex items-center gap-1.5">
              <Stethoscope className="h-3.5 w-3.5 text-muted-foreground" />
              <h2 className="text-sm font-semibold">Historia médica</h2>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Último examen</span>
                <span className="text-foreground">15/03/2025</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Próximo bienal</span>
                <span className="text-foreground">15/03/2027</span>
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-border bg-surface p-4">
            <div className="mb-3 flex items-center gap-1.5">
              <FileText className="h-3.5 w-3.5 text-muted-foreground" />
              <h2 className="text-sm font-semibold">Documentos vinculados</h2>
            </div>
            <p className="text-xs text-muted-foreground">
              14 documentos relacionados con este trabajador.
            </p>
            <Link
              href={`/documents?linked=${worker.id}`}
              className="mt-2 inline-block text-xs text-accent hover:underline"
            >
              Ver todos →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Worker["status"] }) {
  const map = {
    active: { label: "Activa", cls: "text-success bg-success-subtle" },
    suspended: { label: "Suspendida", cls: "text-warning bg-warning-subtle" },
    onboarding: { label: "En incorporación", cls: "text-info bg-info-subtle" },
    terminated: { label: "Terminada", cls: "text-muted-foreground bg-muted" },
  }[status];
  return (
    <span className={cn("rounded-md px-1.5 py-0.5 font-medium", map.cls)}>{map.label}</span>
  );
}

function AuthorizationBadge({
  state,
}: {
  state: "vigente" | "por_vencer" | "expirada";
}) {
  const map = {
    vigente: { label: "✓ Vigente", cls: "text-success bg-success-subtle" },
    por_vencer: { label: "⚠ Renovar", cls: "text-warning bg-warning-subtle" },
    expirada: { label: "✕ Expirada", cls: "text-danger bg-danger-subtle" },
  }[state];
  return (
    <span className={cn("rounded-md px-2 py-0.5 text-[10px] font-medium", map.cls)}>
      {map.label}
    </span>
  );
}

function SparkChart({ values }: { values: number[] }) {
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  return (
    <div className="flex h-16 items-end gap-1">
      {values.map((v, i) => {
        const height = ((v - min) / range) * 80 + 20;
        return (
          <div
            key={i}
            className="flex-1 rounded-t bg-accent-subtle transition-colors hover:bg-accent"
            style={{ height: `${height}%` }}
            title={`Mes ${i + 1}: ${v.toFixed(2)} mSv`}
          />
        );
      })}
    </div>
  );
}
