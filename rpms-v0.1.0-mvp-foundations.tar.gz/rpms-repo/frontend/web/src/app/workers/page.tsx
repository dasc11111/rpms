import Link from "next/link";
import { Plus, Search } from "lucide-react";

const WORKERS = [
  { id: "w-1", name: "Javiera Muñoz", rut: "17.245.892-0", role: "Físico Médico", service: "Radioterapia", category: "A", status: "active", annualDose: 3.2 },
  { id: "w-2", name: "Marcelo Rojas", rut: "18.123.456-3", role: "Tecnólogo Médico", service: "Medicina Nuclear", category: "A", status: "active", annualDose: 4.1 },
  { id: "w-3", name: "Camila Torres", rut: "15.987.654-3", role: "Ingeniero Mantenimiento", service: "Biomédica", category: "B", status: "active", annualDose: 0.8 },
  { id: "w-4", name: "Andrés Silva", rut: "16.456.789-3", role: "Radiofarmaceuta", service: "Medicina Nuclear", category: "A", status: "suspended", annualDose: 2.4 },
];

export default function WorkersPage() {
  return (
    <div className="mx-auto max-w-[1400px] p-6">
      <div className="mb-4 flex items-baseline justify-between">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">Trabajadores</h1>
          <p className="text-xs text-muted-foreground">218 activos · 4 suspendidos · 2 en incorporación</p>
        </div>
        <button
          type="button"
          className="flex h-9 items-center gap-1.5 rounded-md bg-accent px-3 text-xs font-medium text-accent-foreground hover:opacity-90"
        >
          <Plus className="h-3.5 w-3.5" strokeWidth={2.5} />
          Nuevo trabajador
        </button>
      </div>

      <div className="mb-3 flex items-center gap-2">
        <div className="flex h-8 flex-1 max-w-sm items-center gap-2 rounded-md border border-border bg-surface px-2.5 text-xs">
          <Search className="h-3.5 w-3.5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar por nombre o RUT…"
            className="flex-1 bg-transparent outline-none placeholder:text-muted-foreground"
          />
        </div>
        <button className="rounded-md border border-border bg-surface px-2.5 py-1.5 text-xs text-muted-foreground hover:border-accent">
          Todos
        </button>
        <button className="rounded-md border border-border bg-surface px-2.5 py-1.5 text-xs text-muted-foreground hover:border-accent">
          Categoría A
        </button>
        <button className="rounded-md border border-border bg-surface px-2.5 py-1.5 text-xs text-muted-foreground hover:border-accent">
          Con anomalía
        </button>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-surface">
        <table className="w-full">
          <thead className="border-b border-border bg-muted/40 text-left text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-3 py-2">Trabajador</th>
              <th className="px-3 py-2">RUT</th>
              <th className="px-3 py-2">Rol</th>
              <th className="px-3 py-2">Servicio</th>
              <th className="px-3 py-2">Cat.</th>
              <th className="px-3 py-2">Estado</th>
              <th className="px-3 py-2 text-right">Dosis 2026</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border text-sm">
            {WORKERS.map((w) => (
              <tr key={w.id} className="hover:bg-muted/40">
                <td className="px-3 py-2.5">
                  <Link href={`/workers/${w.id}`} className="font-medium text-foreground hover:text-accent">
                    {w.name}
                  </Link>
                </td>
                <td className="px-3 py-2.5 font-mono text-xs text-muted-foreground">{w.rut}</td>
                <td className="px-3 py-2.5 text-muted-foreground">{w.role}</td>
                <td className="px-3 py-2.5 text-muted-foreground">{w.service}</td>
                <td className="px-3 py-2.5">
                  <span className="rounded-md bg-info-subtle px-1.5 py-0.5 text-[10px] font-medium text-info">
                    {w.category}
                  </span>
                </td>
                <td className="px-3 py-2.5">
                  {w.status === "active" ? (
                    <span className="rounded-md bg-success-subtle px-1.5 py-0.5 text-[10px] font-medium text-success">
                      Activa
                    </span>
                  ) : (
                    <span className="rounded-md bg-warning-subtle px-1.5 py-0.5 text-[10px] font-medium text-warning">
                      Suspendida
                    </span>
                  )}
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums text-muted-foreground">
                  {w.annualDose.toFixed(2)} mSv
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
