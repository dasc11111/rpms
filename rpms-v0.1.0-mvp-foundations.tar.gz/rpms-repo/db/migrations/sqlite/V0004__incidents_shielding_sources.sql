-- V0004: incidentes, auditorías, blindajes, fuentes radiactivas, radiofármacos, residuos
-- Dialect: PostgreSQL 16

BEGIN;

-- =====================================================================
-- Tabla: incident
-- =====================================================================
CREATE TABLE incident (
    id                    TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id             TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    reference_code        TEXT NOT NULL,
    reported_by           TEXT REFERENCES app_user(id),
    reported_at           TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    occurred_at           TEXT NOT NULL,
    incident_type         TEXT NOT NULL,
    severity              TEXT NOT NULL
                          CHECK (severity IN ('L1','L2','L3','L4','L5')),
    ines_level            SMALLINT CHECK (ines_level BETWEEN 0 AND 7),
    location_room_id      TEXT REFERENCES room(id),
    equipment_id          TEXT REFERENCES equipment(id),
    narrative             TEXT NOT NULL,
    root_cause_analysis   TEXT NOT NULL DEFAULT '{}',
    workers_involved      TEXT NOT NULL DEFAULT '[]',
    status                TEXT NOT NULL DEFAULT 'open'
                          CHECK (status IN ('open','investigating','in_action','closed','regulatory_notified')),
    notified_authority_at TEXT,
    closed_at             TEXT,
    created_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, reference_code)
);

CREATE INDEX ix_incident_tenant  ON incident(tenant_id);
CREATE INDEX ix_incident_status  ON incident(status) WHERE status != 'closed';
CREATE INDEX ix_incident_severity ON incident(severity);

-- =====================================================================
-- Tabla: incident_action (planes de acción)
-- =====================================================================
CREATE TABLE incident_action (
    id            TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    incident_id   TEXT NOT NULL REFERENCES incident(id) ON DELETE CASCADE,
    description   TEXT NOT NULL,
    assignee_id   TEXT REFERENCES app_user(id),
    due_at        DATE,
    completed_at  TEXT,
    status        TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','in_progress','done','cancelled')),
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================================
-- Tabla: audit
-- =====================================================================
CREATE TABLE audit (
    id             TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id      TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    scope          TEXT NOT NULL,
    audit_type     TEXT NOT NULL CHECK (audit_type IN ('internal','external','regulatory','vendor')),
    planned_date   DATE NOT NULL,
    executed_date  DATE,
    auditor_name   TEXT,
    auditor_org    TEXT,
    findings       TEXT NOT NULL DEFAULT '[]',
    status         TEXT NOT NULL DEFAULT 'planned'
                   CHECK (status IN ('planned','in_progress','completed','followup')),
    report_document_id TEXT REFERENCES document(id),
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_regaudit_tenant ON audit(tenant_id);
CREATE INDEX ix_regaudit_status ON audit(status);

-- =====================================================================
-- Tabla: shielding (blindajes por sala)
-- =====================================================================
CREATE TABLE shielding (
    id                     TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id              TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    room_id                TEXT NOT NULL REFERENCES room(id) ON DELETE CASCADE,
    wall                   TEXT NOT NULL
                           CHECK (wall IN ('N','S','E','W','ceiling','floor','door','window')),
    material               TEXT NOT NULL,
    thickness_mm           NUMERIC NOT NULL,
    design_document_id     TEXT REFERENCES document(id),
    calculation_document_id TEXT REFERENCES document(id),
    last_inspection_at     DATE,
    notes                  TEXT,
    created_at             TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_shielding_room ON shielding(room_id);

-- =====================================================================
-- Tabla: radioactive_source (fuentes selladas)
-- =====================================================================
CREATE TABLE radioactive_source (
    id                    TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id             TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    isotope               TEXT NOT NULL,   -- Ir-192, Co-60, Cs-137, ...
    source_type           TEXT NOT NULL CHECK (source_type IN ('sealed','unsealed')),
    activity_bq_initial   NUMERIC NOT NULL,
    activity_date         DATE NOT NULL,
    half_life_days        NUMERIC NOT NULL,
    serial_number         TEXT,
    manufacturer          TEXT,
    location_room_id      TEXT REFERENCES room(id),
    category_iaea         SMALLINT CHECK (category_iaea BETWEEN 1 AND 5),
    status                TEXT NOT NULL DEFAULT 'in_use'
                          CHECK (status IN ('in_use','in_storage','decay_storage','disposed','lost')),
    disposed_at           DATE,
    disposal_route        TEXT,
    created_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, manufacturer, serial_number, isotope)
);

CREATE INDEX ix_source_tenant ON radioactive_source(tenant_id);
CREATE INDEX ix_source_status ON radioactive_source(status);

-- =====================================================================
-- Tabla: radiopharmaceutical
-- =====================================================================
CREATE TABLE radiopharmaceutical (
    id                    TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id             TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    name                  TEXT NOT NULL,
    isotope               TEXT NOT NULL,
    batch                 TEXT NOT NULL,
    activity_bq           NUMERIC NOT NULL,
    calibration_datetime  TEXT NOT NULL,
    received_at           TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    supplier              TEXT,
    expiration_at         TEXT,
    used                  BOOLEAN NOT NULL DEFAULT FALSE,
    used_at               TEXT,
    used_for_study        TEXT,
    remaining_activity_bq NUMERIC,
    disposed_as_waste_id  TEXT,
    created_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_rp_tenant ON radiopharmaceutical(tenant_id);
CREATE INDEX ix_rp_isotope ON radiopharmaceutical(isotope);

-- =====================================================================
-- Tabla: radioactive_waste
-- =====================================================================
CREATE TABLE radioactive_waste (
    id                 TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id          TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    waste_code         TEXT NOT NULL,
    isotope            TEXT NOT NULL,
    initial_activity_bq NUMERIC NOT NULL,
    stored_at          TEXT NOT NULL,
    storage_room_id    TEXT REFERENCES room(id),
    half_life_days     NUMERIC NOT NULL,
    ready_for_disposal_at DATE,
    disposed_at        TEXT,
    disposal_route     TEXT,
    status             TEXT NOT NULL DEFAULT 'in_decay'
                       CHECK (status IN ('in_decay','ready_for_disposal','disposed')),
    created_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, waste_code)
);

CREATE INDEX ix_waste_tenant ON radioactive_waste(tenant_id);
CREATE INDEX ix_waste_status ON radioactive_waste(status);

COMMIT;
