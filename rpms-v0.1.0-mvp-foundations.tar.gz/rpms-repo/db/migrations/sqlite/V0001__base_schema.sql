-- V0001: base schema — tenants, workers, facilities, services, rooms
-- Dialect: PostgreSQL 16

BEGIN;

-- Extensiones requeridas (a activar en producción, se listan por documentación)
-- CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- CREATE EXTENSION IF NOT EXISTS pg_trgm;
-- CREATE EXTENSION IF NOT EXISTS "TEXT-ossp";
-- CREATE EXTENSION IF NOT EXISTS vector;
-- CREATE EXTENSION IF NOT EXISTS timescaledb;

-- =====================================================================
-- Tabla: tenant
-- =====================================================================
CREATE TABLE tenant (
    id                      TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    name                    TEXT NOT NULL,
    slug                    TEXT NOT NULL UNIQUE,
    country_code            TEXT NOT NULL,
    jurisdiction_profile_id TEXT,
    plan                    TEXT NOT NULL DEFAULT 'starter',
    data_region             TEXT NOT NULL DEFAULT 'scl',
    status                  TEXT NOT NULL DEFAULT 'active'
                            CHECK (status IN ('active','suspended','archived')),
    created_at              TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_tenant_country ON tenant(country_code);
CREATE INDEX ix_tenant_status  ON tenant(status);

-- =====================================================================
-- Tabla: app_user (identidad de plataforma)
-- =====================================================================
CREATE TABLE app_user (
    id                      TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id               TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    email                   TEXT NOT NULL,
    phone                   TEXT,
    full_name               TEXT NOT NULL,
    identity_provider_sub   TEXT,
    mfa_enabled             BOOLEAN NOT NULL DEFAULT FALSE,
    status                  TEXT NOT NULL DEFAULT 'active'
                            CHECK (status IN ('active','suspended','deactivated')),
    last_login_at           TEXT,
    created_at              TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, email)
);

CREATE INDEX ix_user_tenant ON app_user(tenant_id);

-- =====================================================================
-- Tabla: facility (instalación radiactiva)
-- =====================================================================
CREATE TABLE facility (
    id            TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id     TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    name          TEXT NOT NULL,
    facility_type TEXT NOT NULL
                  CHECK (facility_type IN ('hospital','clinic','pet_center','industrial',
                                           'academic','veterinary','dental','laboratory',
                                           'regulator')),
    address       TEXT,
    city          TEXT,
    country_code  TEXT NOT NULL,
    latitude      NUMERIC,
    longitude     NUMERIC,
    status        TEXT NOT NULL DEFAULT 'active',
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_facility_tenant ON facility(tenant_id);

-- =====================================================================
-- Tabla: service (unidad clínica / servicio radiológico)
-- =====================================================================
CREATE TABLE service (
    id             TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id      TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    facility_id    TEXT NOT NULL REFERENCES facility(id) ON DELETE CASCADE,
    name           TEXT NOT NULL,
    service_type   TEXT NOT NULL
                   CHECK (service_type IN ('radiotherapy','nuclear_medicine','imaging',
                                           'interventional','dental','industrial',
                                           'research','other')),
    head_user_id   TEXT REFERENCES app_user(id),
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_service_facility ON service(facility_id);

-- =====================================================================
-- Tabla: room (sala física)
-- =====================================================================
CREATE TABLE room (
    id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id    TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    service_id   TEXT NOT NULL REFERENCES service(id) ON DELETE CASCADE,
    code         TEXT NOT NULL,
    name         TEXT NOT NULL,
    room_type    TEXT NOT NULL
                 CHECK (room_type IN ('bunker','ct','pet','mri','xray','fluoro',
                                      'mammo','angio','brachy','source_storage',
                                      'waste','control','other')),
    floor        TEXT,
    area_m2      NUMERIC,
    created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (service_id, code)
);

-- =====================================================================
-- Tabla: worker (persona ocupacionalmente expuesta - POE)
-- =====================================================================
CREATE TABLE worker (
    id                    TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id             TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    national_id           TEXT NOT NULL,
    national_id_country   TEXT NOT NULL DEFAULT 'CL',
    full_name             TEXT NOT NULL,
    birth_date            DATE,
    sex                   TEXT CHECK (sex IN ('F','M','X')),
    photo_url             TEXT,
    signature_url         TEXT,
    profession            TEXT,
    job_title             TEXT,
    icrp_category         TEXT CHECK (icrp_category IN ('A','B')),
    primary_facility_id   TEXT REFERENCES facility(id),
    primary_service_id    TEXT REFERENCES service(id),
    hire_date             DATE,
    status                TEXT NOT NULL DEFAULT 'active'
                          CHECK (status IN ('active','suspended','onboarding','terminated')),
    qr_token              TEXT UNIQUE,
    created_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, national_id, national_id_country)
);

CREATE INDEX ix_worker_tenant       ON worker(tenant_id);
CREATE INDEX ix_worker_service      ON worker(primary_service_id);
CREATE INDEX ix_worker_status       ON worker(status) WHERE status = 'active';
-- (skipped: pg-specific index)

-- =====================================================================
-- Auditoría (append-only)
-- =====================================================================
CREATE TABLE audit_log (
    id           INTEGER PRIMARY KEY,
    at           TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    tenant_id    TEXT,
    actor_user_id TEXT,
    actor_kind   TEXT NOT NULL CHECK (actor_kind IN ('user','service','ai','system')),
    action       TEXT NOT NULL,
    entity_type  TEXT NOT NULL,
    entity_id    TEXT,
    payload      TEXT NOT NULL DEFAULT '{}',
    ip_address   TEXT,
    user_agent   TEXT,
    session_id   TEXT
);

CREATE INDEX ix_audit_at        ON audit_log(at DESC);
CREATE INDEX ix_audit_entity    ON audit_log(entity_type, entity_id);
CREATE INDEX ix_audit_tenant    ON audit_log(tenant_id, at DESC);

COMMIT;
