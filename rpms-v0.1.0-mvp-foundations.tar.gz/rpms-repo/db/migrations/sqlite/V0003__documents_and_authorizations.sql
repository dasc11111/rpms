-- V0003: documents (con chunks vectorizados), autorizaciones, licencias, capacitaciones
-- Dialect: PostgreSQL 16 (con pgvector)

BEGIN;

-- =====================================================================
-- Tabla: document (gestión documental)
-- =====================================================================
CREATE TABLE document (
    id                  TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id           TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    original_filename   TEXT NOT NULL,
    sha256              TEXT NOT NULL,
    size_bytes          BIGINT NOT NULL,
    mime_type           TEXT NOT NULL,
    storage_uri         TEXT NOT NULL,
    document_type       TEXT,  -- ver diccionario DT001..DTNNN
    document_type_confidence NUMERIC,
    version             INT NOT NULL DEFAULT 1,
    parent_document_id  TEXT REFERENCES document(id),
    worm_locked         BOOLEAN NOT NULL DEFAULT FALSE,
    ocr_status          TEXT NOT NULL DEFAULT 'pending'
                        CHECK (ocr_status IN ('pending','processing','done','failed','skipped')),
    ocr_engine          TEXT,
    ocr_completed_at    TEXT,
    extracted_metadata  TEXT NOT NULL DEFAULT '{}',
    related_entities    TEXT NOT NULL DEFAULT '[]',
    -- related_entities: [{"type":"worker","id":"...","score":0.94}, ...]
    uploaded_by         TEXT REFERENCES app_user(id),
    uploaded_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, sha256, version)
);

CREATE INDEX ix_document_tenant       ON document(tenant_id);
CREATE INDEX ix_document_type         ON document(document_type);
-- (skipped: pg-specific index)
-- (skipped: pg-specific index)

-- =====================================================================
-- Tabla: document_chunk (para RAG - texto + embedding)
-- =====================================================================
CREATE TABLE document_chunk (
    id            TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id     TEXT NOT NULL,
    document_id   TEXT NOT NULL REFERENCES document(id) ON DELETE CASCADE,
    chunk_index   INT NOT NULL,
    page          INT,
    bbox          TEXT,
    text          TEXT NOT NULL,
    -- Producción: embedding VECTOR(1024) con extensión pgvector
    embedding     TEXT,  -- placeholder; en Postgres real es VECTOR
    token_count   INT,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (document_id, chunk_index)
);

CREATE INDEX ix_chunk_document ON document_chunk(document_id);
-- (skipped: pg-specific index)
-- Producción: -- (skipped: pg-specific index)

-- =====================================================================
-- Tabla: authorization (autorización individual del trabajador)
-- =====================================================================
CREATE TABLE authorization (
    id                TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id         TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    worker_id         TEXT NOT NULL REFERENCES worker(id) ON DELETE CASCADE,
    authorization_type TEXT NOT NULL
                      CHECK (authorization_type IN ('operator','opr','opr_alternate',
                                                    'medical_physicist','radiopharmacist',
                                                    'source_carrier','other')),
    scope             TEXT NOT NULL DEFAULT '[]',
    issued_by         TEXT NOT NULL,
    issued_at         DATE NOT NULL,
    expires_at        DATE,
    document_id       TEXT REFERENCES document(id),
    number            TEXT,
    status            TEXT NOT NULL DEFAULT 'active'
                      CHECK (status IN ('active','expired','revoked','pending')),
    created_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_auth_worker      ON authorization(worker_id);
CREATE INDEX ix_auth_expires     ON authorization(expires_at) WHERE status = 'active';
CREATE INDEX ix_auth_type        ON authorization(authorization_type);

-- =====================================================================
-- Tabla: license (licencia de instalación o de equipo)
-- =====================================================================
CREATE TABLE license (
    id            TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id     TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    subject_type  TEXT NOT NULL CHECK (subject_type IN ('facility','equipment','worker')),
    subject_id    TEXT NOT NULL,
    license_type  TEXT NOT NULL,
    number        TEXT NOT NULL,
    issued_by     TEXT NOT NULL,
    issued_at     DATE NOT NULL,
    expires_at    DATE,
    document_id   TEXT REFERENCES document(id),
    status        TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','expired','revoked','pending')),
    metadata      TEXT NOT NULL DEFAULT '{}',
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_license_subject ON license(subject_type, subject_id);
CREATE INDEX ix_license_expires ON license(expires_at) WHERE status = 'active';

-- =====================================================================
-- Tabla: training (capacitación)
-- =====================================================================
CREATE TABLE training (
    id                 TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id          TEXT NOT NULL REFERENCES tenant(id) ON DELETE CASCADE,
    worker_id          TEXT NOT NULL REFERENCES worker(id) ON DELETE CASCADE,
    course_name        TEXT NOT NULL,
    course_provider    TEXT,
    hours              NUMERIC,
    date_completed     DATE NOT NULL,
    certificate_document_id TEXT REFERENCES document(id),
    next_renewal_at    DATE,
    created_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_training_worker  ON training(worker_id);
CREATE INDEX ix_training_renewal ON training(next_renewal_at);

-- =====================================================================
-- Tabla: knowledge_edge (motor de relaciones - grafo)
-- =====================================================================
CREATE TABLE knowledge_edge (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||substr(lower(hex(randomblob(2))),2)||'-'||substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||lower(hex(randomblob(6)))),
    tenant_id       TEXT NOT NULL,
    source_type     TEXT NOT NULL,
    source_id       TEXT NOT NULL,
    target_type     TEXT NOT NULL,
    target_id       TEXT NOT NULL,
    relation        TEXT NOT NULL,
    weight          NUMERIC NOT NULL DEFAULT 1.0,
    metadata        TEXT NOT NULL DEFAULT '{}',
    discovered_by   TEXT NOT NULL CHECK (discovered_by IN ('rule','ai','user','import')),
    discovered_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (tenant_id, source_type, source_id, target_type, target_id, relation)
);

CREATE INDEX ix_edge_src ON knowledge_edge(tenant_id, source_type, source_id);
CREATE INDEX ix_edge_tgt ON knowledge_edge(tenant_id, target_type, target_id);
CREATE INDEX ix_edge_rel ON knowledge_edge(tenant_id, relation);

COMMIT;
