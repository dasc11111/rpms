#!/usr/bin/env python3
"""
Aplica migraciones SQL al motor indicado.

- Modo `postgres`: pasa el SQL tal cual (requiere psycopg y DATABASE_URL).
- Modo `sqlite`: traduce el dialecto PostgreSQL a SQLite y aplica al archivo.

Uso:
    python apply_migrations.py --dialect sqlite --db /tmp/rpms_dev.sqlite
    python apply_migrations.py --dialect postgres  # usa DATABASE_URL

El traductor cubre lo necesario para MVP (no pretende ser exhaustivo):
- gen_random_uuid() -> lower(hex(randomblob(16)))
- TIMESTAMPTZ / TIMESTAMP -> TEXT (ISO-8601)
- JSONB / JSON -> TEXT
- BIGSERIAL -> INTEGER PRIMARY KEY AUTOINCREMENT
- UUID -> TEXT
- INET -> TEXT
- CREATE INDEX ... USING GIN|hnsw -> se ignoran
- CREATE SCHEMA -> se ignora, SET search_path -> se ignora
- Comentarios y BEGIN/COMMIT respetados
"""

from __future__ import annotations

import argparse
import os
import re
import sqlite3
import sys
from pathlib import Path

MIGRATIONS_DIR = Path(__file__).resolve().parents[1] / "migrations"


def translate_postgres_to_sqlite(sql: str) -> str:
    """Traduce SQL de Postgres a SQLite (subset suficiente para MVP)."""
    out = sql

    # Eliminar líneas de schema / search_path
    out = re.sub(r"(?im)^\s*CREATE\s+SCHEMA[^;]+;\s*$", "", out)
    out = re.sub(r"(?im)^\s*SET\s+search_path[^;]+;\s*$", "", out)
    # Eliminar comentarios de línea sql -- (dejar tal cual en realidad; SQLite los soporta)

    # gen_random_uuid() -> generador pseudo-uuid v4 con hex y randomblob
    # Formato: 8-4-4-4-12
    uuid_expr = (
        "(lower(hex(randomblob(4)))||'-'||lower(hex(randomblob(2)))||'-4'||"
        "substr(lower(hex(randomblob(2))),2)||'-'||"
        "substr('89ab',abs(random())%4+1,1)||substr(lower(hex(randomblob(2))),2)||'-'||"
        "lower(hex(randomblob(6))))"
    )
    out = out.replace("gen_random_uuid()", uuid_expr)

    # NOW() -> CURRENT_TIMESTAMP
    out = re.sub(r"\bNOW\s*\(\s*\)", "CURRENT_TIMESTAMP", out, flags=re.IGNORECASE)

    # Tipos
    type_map = [
        (r"\bTIMESTAMPTZ\b", "TEXT"),
        (r"\bTIMESTAMP\b", "TEXT"),
        (r"\bJSONB\b", "TEXT"),
        (r"\bJSON\b", "TEXT"),
        (r"\bUUID\b", "TEXT"),
        (r"\bINET\b", "TEXT"),
        (r"\bBIGSERIAL\b", "INTEGER"),
        (r"\bSERIAL\b", "INTEGER"),
        (r"\bNUMERIC\s*\(\s*\d+\s*,\s*\d+\s*\)", "NUMERIC"),
        (r"\bNUMERIC\s*\(\s*\d+\s*\)", "NUMERIC"),
        (r"\bCHAR\s*\(\s*\d+\s*\)", "TEXT"),
        (r"\bTEXT\[\]", "TEXT"),
    ]
    for pattern, repl in type_map:
        out = re.sub(pattern, repl, out, flags=re.IGNORECASE)

    # DEFAULT '...'::jsonb -> DEFAULT '...'
    out = re.sub(r"::(jsonb|json|uuid|text|inet)", "", out, flags=re.IGNORECASE)

    # ON DELETE CASCADE/RESTRICT -> mantener
    # Eliminar índices GIN/hnsw completos (multilínea hasta punto y coma)
    out = re.sub(
        r"CREATE\s+INDEX[^;]*?USING\s+(GIN|hnsw|gist)[^;]*;",
        "-- (skipped: pg-specific index)",
        out,
        flags=re.IGNORECASE | re.DOTALL,
    )

    # WHERE clause con GIN eliminado ya, pero también partial indexes con WHERE
    # se soportan en SQLite, dejamos como están.

    # BOOL_OR() -> MAX() en agregación (aproximación aceptable)
    out = re.sub(r"\bBOOL_OR\s*\(", "MAX(", out, flags=re.IGNORECASE)

    # date_trunc('month', x) -> strftime('%Y-%m-01', x)
    out = re.sub(
        r"date_trunc\s*\(\s*'month'\s*,\s*([^)]+)\)",
        r"strftime('%Y-%m-01', \1)",
        out,
        flags=re.IGNORECASE,
    )
    out = re.sub(
        r"date_trunc\s*\(\s*'day'\s*,\s*([^)]+)\)",
        r"strftime('%Y-%m-%d', \1)",
        out,
        flags=re.IGNORECASE,
    )

    return out


def apply_sqlite(db_path: str, fresh: bool = True, verbose: bool = True) -> None:
    if fresh and os.path.exists(db_path):
        os.remove(db_path)
        if verbose:
            print(f"→ Borrado previo de {db_path}")
    con = sqlite3.connect(db_path)
    con.executescript("PRAGMA foreign_keys = ON;")
    files = sorted((MIGRATIONS_DIR / "postgres").glob("V*.sql"))
    if not files:
        print("No hay migraciones en", MIGRATIONS_DIR / "postgres")
        return
    for f in files:
        raw = f.read_text(encoding="utf-8")
        translated = translate_postgres_to_sqlite(raw)
        if verbose:
            print(f"→ Aplicando {f.name} ({len(translated)} chars traducidos)")
        try:
            con.executescript(translated)
            con.commit()
        except sqlite3.Error as e:
            print(f"  ERROR: {e}")
            print("--- SQL traducido (primeras 40 líneas) ---")
            for i, line in enumerate(translated.splitlines()[:40], 1):
                print(f"{i:3}: {line}")
            raise
    # Volcar variante traducida a disco (para auditoría)
    out_dir = MIGRATIONS_DIR / "sqlite"
    out_dir.mkdir(parents=True, exist_ok=True)
    for f in files:
        translated = translate_postgres_to_sqlite(f.read_text(encoding="utf-8"))
        (out_dir / f.name).write_text(translated, encoding="utf-8")
    if verbose:
        print(f"✔ Migraciones aplicadas correctamente a {db_path}")
    # Sanity check: tablas creadas
    cur = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    )
    tables = [r[0] for r in cur.fetchall()]
    if verbose:
        print(f"✔ Tablas ({len(tables)}): {', '.join(tables)}")
    con.close()


def apply_postgres() -> None:
    print("Modo Postgres requiere psycopg y DATABASE_URL. No implementado en sandbox.")
    sys.exit(2)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dialect", choices=["postgres", "sqlite"], required=True)
    ap.add_argument("--db", default="/tmp/rpms_dev.sqlite")
    ap.add_argument("--keep", action="store_true", help="No borrar la BD SQLite existente")
    args = ap.parse_args()
    if args.dialect == "sqlite":
        apply_sqlite(args.db, fresh=not args.keep)
    else:
        apply_postgres()


if __name__ == "__main__":
    main()
