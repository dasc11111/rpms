#!/usr/bin/env python3
"""
Seed de datos de demostración para RPMS.

Crea:
- 1 tenant (Hospital San Rafael, CL)
- 1 facility, 3 services (Radioterapia, Medicina Nuclear, Imagenología)
- 5 rooms
- 12 workers POE (categorías A y B)
- 4 equipos (LINAC, PET/CT, CT, Mamógrafo)
- 6 dosímetros activos
- Lecturas dosimétricas de los últimos 12 meses
- 3 autorizaciones
- 2 licencias
- Instrumentos y calibraciones
- 1 incidente abierto de ejemplo
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import sqlite3
import uuid
from datetime import date, datetime, timedelta, timezone

random.seed(42)


def new_uuid() -> str:
    return str(uuid.uuid4())


def iso(dt) -> str:
    if isinstance(dt, datetime):
        return dt.astimezone(timezone.utc).isoformat()
    if isinstance(dt, date):
        return dt.isoformat()
    return str(dt)


def seed(db_path: str) -> None:
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON;")
    cur = con.cursor()

    # ---------------- Tenant ----------------
    tenant_id = new_uuid()
    cur.execute(
        """INSERT INTO tenant (id, name, slug, country_code, plan, data_region, status)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (tenant_id, "Hospital San Rafael", "hsr-cl", "CL", "professional", "scl", "active"),
    )

    # ---------------- Facility ----------------
    facility_id = new_uuid()
    cur.execute(
        """INSERT INTO facility (id, tenant_id, name, facility_type, address, city, country_code, latitude, longitude)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (facility_id, tenant_id, "Hospital San Rafael Central", "hospital",
         "Av. Independencia 1027", "Santiago", "CL", -33.4184, -70.6534),
    )

    # ---------------- Users ----------------
    admin_user_id = new_uuid()
    cur.execute(
        """INSERT INTO app_user (id, tenant_id, email, full_name, mfa_enabled, status)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (admin_user_id, tenant_id, "javiera.munoz@hsr.cl", "Javiera Muñoz", 1, "active"),
    )

    # ---------------- Services ----------------
    services = []
    for name, stype in [
        ("Radioterapia", "radiotherapy"),
        ("Medicina Nuclear", "nuclear_medicine"),
        ("Imagenología", "imaging"),
    ]:
        sid = new_uuid()
        services.append((sid, name, stype))
        cur.execute(
            """INSERT INTO service (id, tenant_id, facility_id, name, service_type, head_user_id)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (sid, tenant_id, facility_id, name, stype, admin_user_id),
        )

    # ---------------- Rooms ----------------
    rooms = []
    room_defs = [
        (services[0][0], "RT-B01", "Búnker LINAC 1", "bunker"),
        (services[0][0], "RT-B02", "Búnker Braquiterapia", "brachy"),
        (services[1][0], "MN-01", "Sala PET/CT", "pet"),
        (services[1][0], "MN-02", "Almacén Fuentes MN", "source_storage"),
        (services[2][0], "IM-01", "Sala TC 1", "ct"),
    ]
    for sid, code, name, rtype in room_defs:
        rid = new_uuid()
        rooms.append((rid, sid, code, name, rtype))
        cur.execute(
            """INSERT INTO room (id, tenant_id, service_id, code, name, room_type, floor, area_m2)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (rid, tenant_id, sid, code, name, rtype, "1", 42.5),
        )

    # ---------------- Workers ----------------
    # RUTs con DV correcto (calculados con algoritmo módulo 11)
    worker_defs = [
        ("172458920", "Javiera Muñoz",   "F", "Físico Médico",       "A", services[0][0]),
        ("181234563", "Marcelo Rojas",   "M", "Tecnólogo Médico",    "A", services[0][0]),
        ("159876543", "Camila Torres",   "F", "Tecnólogo Médico",    "A", services[0][0]),
        ("164567893", "Andrés Silva",    "M", "Radioterapeuta",      "A", services[0][0]),
        ("193456782", "Paulina Vega",    "F", "Enfermera",           "B", services[0][0]),
        ("178901230", "Roberto Díaz",    "M", "Físico Médico",       "A", services[1][0]),
        ("185678903", "Fernanda Lira",   "F", "Tecnólogo Médico",    "A", services[1][0]),
        ("162345672", "Diego Cabrera",   "M", "Radiofarmaceuta",     "A", services[1][0]),
        ("156789011", "Sofía Herrera",   "F", "Tecnólogo Médico",    "A", services[2][0]),
        ("174567891", "Cristián López",  "M", "Radiólogo",           "A", services[2][0]),
        ("190123456", "Antonia Pérez",   "F", "Tecnólogo Médico",    "A", services[2][0]),
        ("189012349", "Matías Cortés",   "M", "Director PR",         "B", services[0][0]),
    ]

    workers = []
    for rut, name, sex, prof, cat, sid in worker_defs:
        wid = new_uuid()
        workers.append((wid, name, cat, sid))
        cur.execute(
            """INSERT INTO worker (id, tenant_id, national_id, national_id_country,
                                    full_name, sex, profession, job_title, icrp_category,
                                    primary_facility_id, primary_service_id, hire_date,
                                    status, qr_token)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (wid, tenant_id, rut, "CL", name, sex, prof, prof, cat,
             facility_id, sid, "2020-03-15", "active", f"QR-{rut}"),
        )

    # ---------------- Equipment ----------------
    equipment = []
    eq_defs = [
        (rooms[0][0], services[0][0], "linac", "Varian", "TrueBeam", "TB-45781"),
        (rooms[1][0], services[0][0], "brachytherapy", "Elekta", "Flexitron", "FLX-12043"),
        (rooms[2][0], services[1][0], "pet_ct", "Siemens", "Biograph Vision", "BV-87334"),
        (rooms[4][0], services[2][0], "ct", "Siemens", "Somatom Force", "SF-99001"),
    ]
    for room_id, sid, etype, mfr, model, sn in eq_defs:
        eid = new_uuid()
        equipment.append((eid, etype, mfr, model, sn))
        cur.execute(
            """INSERT INTO equipment (id, tenant_id, room_id, service_id, equipment_type,
                                       manufacturer, model, serial_number,
                                       installation_date, commissioning_date, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (eid, tenant_id, room_id, sid, etype, mfr, model, sn,
             "2021-06-01", "2021-08-15", "active"),
        )

    # ---------------- Dosimeters ----------------
    dosimeters = []
    for wid, name, cat, sid in workers[:6]:  # solo 6 con dosímetro cuerpo entero
        did = new_uuid()
        code = f"LD-{random.randint(10000, 99999)}"
        dosimeters.append((did, wid))
        cur.execute(
            """INSERT INTO dosimeter (id, tenant_id, worker_id, dosimeter_type, provider,
                                       external_code, body_location, issued_at, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (did, tenant_id, wid, "tld", "Landauer", code, "whole_body",
             "2025-08-01", "active"),
        )

    # ---------------- Dose readings (últimos 12 meses) ----------------
    today = date(2026, 7, 14)
    for did, wid in dosimeters:
        # Baseline personal (mSv/mes)
        baseline = random.uniform(0.15, 0.60)
        for months_back in range(12, 0, -1):
            year = today.year if today.month - months_back > 0 else today.year - 1
            month = ((today.month - months_back - 1) % 12) + 1
            reading_date = date(year, month, 15)
            hp10 = round(max(0, random.gauss(baseline, baseline * 0.35)), 3)
            hp007 = round(hp10 * random.uniform(1.0, 1.15), 3)
            hp3 = round(hp10 * random.uniform(0.85, 1.0), 3)
            is_anomaly = hp10 > baseline * 3
            cur.execute(
                """INSERT INTO dose_reading (id, time, tenant_id, worker_id, dosimeter_id,
                                              hp10_msv, hp007_msv, hp3_msv,
                                              period_start, period_end,
                                              is_anomaly, anomaly_reason, imported_from)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (new_uuid(), iso(reading_date), tenant_id, wid, did,
                 hp10, hp007, hp3,
                 iso(date(year, month, 1)),
                 iso(date(year, month, 28)),
                 1 if is_anomaly else 0,
                 "Excede 3× baseline personal" if is_anomaly else None,
                 "seed"),
            )

    # ---------------- Authorizations ----------------
    for i, (wid, name, cat, sid) in enumerate(workers[:3]):
        cur.execute(
            """INSERT INTO authorization (id, tenant_id, worker_id, authorization_type,
                                           scope, issued_by, issued_at, expires_at,
                                           number, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (new_uuid(), tenant_id, wid,
             "opr" if i == 0 else "operator",
             json.dumps(["radiotherapy", "linac"]),
             "SEREMI de Salud RM",
             "2024-03-15",
             "2027-03-15" if i > 0 else "2026-08-30",
             f"AUT-{2024}-{1000 + i}",
             "active"),
        )

    # ---------------- Licenses ----------------
    for eid, etype, mfr, model, sn in equipment[:2]:
        cur.execute(
            """INSERT INTO license (id, tenant_id, subject_type, subject_id, license_type,
                                    number, issued_by, issued_at, expires_at, status, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (new_uuid(), tenant_id, "equipment", eid, "operation",
             f"LIC-EQ-{sn}", "SEREMI de Salud RM",
             "2023-01-15", "2028-01-15", "active",
             json.dumps({"norm": "DS 133/1984", "conditions": []})),
        )

    # ---------------- Instruments ----------------
    instrument_defs = [
        ("contamination_monitor", "Ludlum", "Model 3", "LM3-45678"),
        ("area_monitor", "Fluke", "451P", "FLK-99123"),
        ("activity_meter", "Capintec", "CRC-25R", "CAP-77012"),
    ]
    for itype, mfr, model, sn in instrument_defs:
        cur.execute(
            """INSERT INTO instrument (id, tenant_id, owner_service_id, instrument_type,
                                        manufacturer, model, serial_number,
                                        last_calibration_at, next_calibration_at,
                                        qr_token, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (new_uuid(), tenant_id, services[1][0], itype, mfr, model, sn,
             "2025-04-15", "2027-04-15",
             f"INS-{sn}", "active"),
        )

    # ---------------- Incident ----------------
    cur.execute(
        """INSERT INTO incident (id, tenant_id, reference_code, reported_by, reported_at,
                                  occurred_at, incident_type, severity, ines_level,
                                  location_room_id, equipment_id, narrative,
                                  workers_involved, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (new_uuid(), tenant_id, "INC-2026-014", admin_user_id,
         iso(datetime(2026, 7, 12, 14, 25, tzinfo=timezone.utc)),
         iso(datetime(2026, 7, 12, 14, 10, tzinfo=timezone.utc)),
         "dosimetric_investigation", "L2", 1,
         rooms[2][0], equipment[2][0],
         "Alarma de anomalía dosimétrica en trabajador Marcelo Rojas: "
         "lectura mensual 2.8 mSv vs baseline 0.35 mSv. Se inicia investigación.",
         json.dumps([workers[1][0]]),
         "investigating"),
    )

    con.commit()

    # Reportes
    def count(table: str) -> int:
        return cur.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    print("✔ Seed completo. Registros insertados:")
    for table in ("tenant", "app_user", "facility", "service", "room", "worker",
                  "equipment", "dosimeter", "dose_reading", "authorization",
                  "license", "instrument", "incident"):
        print(f"    {table:<20}  {count(table)}")

    con.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="/tmp/rpms_dev.sqlite")
    args = ap.parse_args()
    seed(args.db)


if __name__ == "__main__":
    main()
