output "vpc_id" {
  value       = module.vpc.vpc_id
  description = "VPC ID"
}

output "cluster_endpoint" {
  value       = module.eks.cluster_endpoint
  description = "EKS API server endpoint"
  sensitive   = true
}

output "cluster_name" {
  value       = module.eks.cluster_name
  description = "EKS cluster name"
}

output "postgres_endpoint" {
  value       = module.postgres.db_instance_endpoint
  description = "PostgreSQL endpoint"
  sensitive   = true
}

output "documents_bucket" {
  value       = aws_s3_bucket.documents.bucket
  description = "S3 bucket para documentos (WORM)"
}

output "redis_endpoint" {
  value       = aws_elasticache_replication_group.redis.primary_endpoint_address
  description = "Redis primary endpoint"
  sensitive   = true
}
