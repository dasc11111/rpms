// RPMS — Infrastructure as Code base (AWS)
//
// Provisiona el entorno base para un tenant SaaS multitenant:
// - VPC con subredes públicas y privadas en 3 AZs
// - EKS con managed node groups
// - RDS PostgreSQL 16 con extensiones habilitadas
// - ElastiCache Redis
// - S3 bucket para documentos con Object Lock (WORM)
// - OpenSearch Service
// - Secrets Manager para credenciales
// - IAM roles con least privilege
//
// Uso:
//   cd infra/terraform/environments/dev
//   terraform init
//   terraform plan -var-file=terraform.tfvars
//   terraform apply
//
// Los archivos concretos (main.tf, variables.tf, etc.) se generan
// por ambiente. Este archivo describe el módulo raíz.

terraform {
  required_version = ">= 1.9.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.70"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.32"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.15"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # Backend remoto (S3 + DynamoDB) — configurar por ambiente
  backend "s3" {
    # bucket         = "rpms-terraform-state"
    # key            = "environments/<env>/terraform.tfstate"
    # region         = "us-east-1"
    # dynamodb_table = "rpms-terraform-locks"
    # encrypt        = true
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project     = "RPMS"
      Environment = var.environment
      ManagedBy   = "Terraform"
      Owner       = "platform-team"
    }
  }
}

# =============================================================================
# Networking
# =============================================================================

module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.13"

  name = "rpms-${var.environment}"
  cidr = var.vpc_cidr

  azs             = var.availability_zones
  private_subnets = var.private_subnets
  public_subnets  = var.public_subnets

  enable_nat_gateway   = true
  single_nat_gateway   = var.environment != "prod"
  enable_dns_hostnames = true

  # Endpoints necesarios (evita salir por internet)
  enable_s3_endpoint       = true
  enable_ecr_api_endpoint  = true
  enable_ecr_dkr_endpoint  = true
  enable_logs_endpoint     = true

  tags = {
    "kubernetes.io/cluster/rpms-${var.environment}" = "shared"
  }
}

# =============================================================================
# EKS Cluster
# =============================================================================

module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.24"

  cluster_name    = "rpms-${var.environment}"
  cluster_version = var.kubernetes_version

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  # Autenticación con OIDC (para IRSA)
  enable_irsa                              = true
  cluster_endpoint_public_access           = true
  cluster_endpoint_public_access_cidrs     = var.eks_public_access_cidrs

  # Cifrado de secretos con KMS
  cluster_encryption_config = {
    provider_key_arn = aws_kms_key.eks.arn
    resources        = ["secrets"]
  }

  eks_managed_node_groups = {
    system = {
      desired_size = 2
      min_size     = 2
      max_size     = 4
      instance_types = ["t3.large"]
      labels = {
        workload = "system"
      }
      taints = [{
        key    = "workload"
        value  = "system"
        effect = "NO_SCHEDULE"
      }]
    }
    workload = {
      desired_size = var.workload_node_count
      min_size     = 3
      max_size     = 20
      instance_types = ["m6i.xlarge"]
      labels = {
        workload = "app"
      }
    }
  }
}

resource "aws_kms_key" "eks" {
  description             = "KMS key for EKS secrets encryption"
  deletion_window_in_days = 30
  enable_key_rotation     = true
}

# =============================================================================
# RDS PostgreSQL 16 (con extensiones habilitadas por parameter group)
# =============================================================================

resource "aws_db_parameter_group" "postgres16" {
  name   = "rpms-postgres16-${var.environment}"
  family = "postgres16"

  parameter {
    name  = "shared_preload_libraries"
    value = "pg_stat_statements,timescaledb"
    apply_method = "pending-reboot"
  }

  parameter {
    name  = "log_min_duration_statement"
    value = "1000"  # log queries > 1s
  }

  parameter {
    name  = "log_connections"
    value = "1"
  }

  parameter {
    name  = "pgaudit.log"
    value = "write,ddl"
  }
}

module "postgres" {
  source  = "terraform-aws-modules/rds/aws"
  version = "~> 6.9"

  identifier = "rpms-${var.environment}"

  engine               = "postgres"
  engine_version       = "16.4"
  major_engine_version = "16"
  family               = "postgres16"
  instance_class       = var.rds_instance_class
  allocated_storage    = var.rds_allocated_storage
  storage_encrypted    = true

  db_name  = "rpms"
  username = "rpms_admin"
  port     = 5432
  manage_master_user_password = true

  vpc_security_group_ids = [aws_security_group.postgres.id]
  db_subnet_group_name   = module.vpc.database_subnet_group

  backup_retention_period       = var.environment == "prod" ? 30 : 7
  backup_window                 = "03:00-04:00"
  maintenance_window            = "sun:04:00-sun:05:00"
  performance_insights_enabled  = true
  monitoring_interval           = 30

  parameter_group_name = aws_db_parameter_group.postgres16.name

  # Multi-AZ para prod
  multi_az            = var.environment == "prod"
  deletion_protection = var.environment == "prod"

  skip_final_snapshot = var.environment != "prod"
}

resource "aws_security_group" "postgres" {
  name        = "rpms-postgres-${var.environment}"
  description = "PostgreSQL access from EKS nodes"
  vpc_id      = module.vpc.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [module.eks.node_security_group_id]
  }
}

# =============================================================================
# S3 Bucket con Object Lock (WORM) para documentos regulatorios
# =============================================================================

resource "aws_s3_bucket" "documents" {
  bucket        = "rpms-documents-${var.environment}-${random_id.suffix.hex}"
  force_destroy = var.environment != "prod"

  object_lock_enabled = true
}

resource "aws_s3_bucket_object_lock_configuration" "documents" {
  bucket = aws_s3_bucket.documents.id

  rule {
    default_retention {
      mode = "GOVERNANCE"   # COMPLIANCE en prod para irrevocable
      days = 3650           # 10 años
    }
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "documents" {
  bucket = aws_s3_bucket.documents.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.s3.arn
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_versioning" "documents" {
  bucket = aws_s3_bucket.documents.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_public_access_block" "documents" {
  bucket                  = aws_s3_bucket.documents.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_kms_key" "s3" {
  description             = "KMS key for RPMS S3 encryption"
  deletion_window_in_days = 30
  enable_key_rotation     = true
}

resource "random_id" "suffix" {
  byte_length = 4
}

# =============================================================================
# ElastiCache Redis
# =============================================================================

resource "aws_elasticache_replication_group" "redis" {
  replication_group_id = "rpms-redis-${var.environment}"
  description          = "RPMS Redis cluster"

  engine               = "redis"
  engine_version       = "7.1"
  node_type            = var.redis_node_type
  parameter_group_name = "default.redis7"
  port                 = 6379

  num_cache_clusters         = var.environment == "prod" ? 2 : 1
  automatic_failover_enabled = var.environment == "prod"
  multi_az_enabled           = var.environment == "prod"

  at_rest_encryption_enabled = true
  transit_encryption_enabled = true

  subnet_group_name  = aws_elasticache_subnet_group.redis.name
  security_group_ids = [aws_security_group.redis.id]
}

resource "aws_elasticache_subnet_group" "redis" {
  name       = "rpms-redis-${var.environment}"
  subnet_ids = module.vpc.private_subnets
}

resource "aws_security_group" "redis" {
  name        = "rpms-redis-${var.environment}"
  vpc_id      = module.vpc.vpc_id

  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [module.eks.node_security_group_id]
  }
}
