variable "aws_region" {
  type        = string
  description = "AWS region para desplegar los recursos"
  default     = "sa-east-1"  # São Paulo, cercano a Chile
}

variable "environment" {
  type        = string
  description = "Ambiente: dev | staging | prod"
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment debe ser dev, staging o prod"
  }
}

variable "vpc_cidr" {
  type        = string
  description = "CIDR de la VPC"
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  type        = list(string)
  description = "AZs a usar"
  default     = ["sa-east-1a", "sa-east-1b", "sa-east-1c"]
}

variable "private_subnets" {
  type        = list(string)
  description = "CIDRs de subredes privadas"
  default     = ["10.0.10.0/24", "10.0.11.0/24", "10.0.12.0/24"]
}

variable "public_subnets" {
  type        = list(string)
  description = "CIDRs de subredes públicas"
  default     = ["10.0.20.0/24", "10.0.21.0/24", "10.0.22.0/24"]
}

variable "kubernetes_version" {
  type        = string
  description = "Versión Kubernetes"
  default     = "1.30"
}

variable "eks_public_access_cidrs" {
  type        = list(string)
  description = "CIDRs con acceso público al API server"
  default     = ["0.0.0.0/0"]
}

variable "workload_node_count" {
  type        = number
  description = "Cantidad inicial de nodos worker"
  default     = 3
}

variable "rds_instance_class" {
  type        = string
  description = "Instancia RDS"
  default     = "db.t3.medium"
}

variable "rds_allocated_storage" {
  type        = number
  description = "Almacenamiento RDS en GB"
  default     = 100
}

variable "redis_node_type" {
  type        = string
  description = "Tipo de nodo Redis"
  default     = "cache.t3.micro"
}
