# Radiation Protection Management System (RPMS)
## Documento Maestro de Arquitectura, Producto e Ingeniería

**Versión:** 1.0 — Blueprint fundacional
**Público objetivo:** Comité de arquitectura, dirección médica, oficiales de protección radiológica, CTO/CIO, autoridad regulatoria
**Ámbito:** Latinoamérica (base Chile) con proyección internacional
**Autoría (rol simulado):** Comité multidisciplinario (Físico Médico Senior, OPR, Arquitecto Enterprise, Ingeniero IA, UX Lead, CISO, DevOps Lead)

---

## Tabla de contenidos

1. Visión general del producto y casos de uso
2. Arquitectura funcional
3. Arquitectura técnica
4. Modelo de datos (ERD lógico)
5. Diseño de la base de datos
6. Módulos y submódulos
7. Flujos de trabajo
8. Wireframes y diseño UX/UI
9. Diseño del dashboard ejecutivo
10. APIs y contratos
11. Modelo de permisos y roles
12. Estrategia de IA y automatización
13. Plan de desarrollo por fases (MVP → Enterprise)
14. Estrategia de pruebas y validación
15. Estrategia de despliegue y mantenimiento
16. Recomendaciones para convertirlo en referente internacional
17. Anexos regulatorios (Chile / OIEA / ICRP)

---

# 1. Visión general del producto y casos de uso

## 1.1 Propósito

RPMS es una plataforma **SaaS multitenant**, orientada a IA, para la **gestión integral del ciclo de vida de la protección radiológica** en instalaciones médicas, industriales, académicas y regulatorias. Reemplaza el modelo tradicional de "carpeta compartida + Excel + memoria del OPR" por un ecosistema donde la **información se ingresa una sola vez, se comprende automáticamente y se relaciona sola**.

## 1.2 Principios de producto (no negociables)

| # | Principio | Traducción operacional |
|---|-----------|------------------------|
| P1 | Regla de los 3 clics | Cualquier información crítica accesible en ≤3 clics desde el dashboard. |
| P2 | Cero digitación redundante | El dato se captura una vez (OCR, integración, formulario) y se propaga a todas las entidades. |
| P3 | IA proactiva, no reactiva | El sistema anticipa vencimientos, anomalías dosimétricas y hallazgos regulatorios sin que el usuario pregunte. |
| P4 | Todo relacionado | Grafo de conocimiento interno: trabajador ↔ equipo ↔ sala ↔ dosímetro ↔ documento ↔ incidente ↔ normativa. |
| P5 | Auditable de fábrica | Cada acción firmada, versionada, trazable (WORM opcional). |
| P6 | Regulatory-ready | Reportes exigidos por autoridad se generan en 1 clic con estructura pre-validada. |
| P7 | Diseño-primero | Estética Linear/Notion/Stripe. Nunca ERP feo. |
| P8 | Sub-segundo | Búsqueda universal <500 ms P95, dashboard <1 s. |

## 1.3 Diferenciadores frente a RADGUARD IMS y competidores

1. **RAG documental nativo:** cada documento subido se convierte en conocimiento consultable en lenguaje natural.
2. **Grafo de entidades:** relaciones automáticas basadas en NER (Named Entity Recognition) y reglas de negocio, no en formularios manuales.
3. **Copilot regulatorio chileno:** entrenado con DS 133/1984, DS 3/1985, DS 594, Código Sanitario, resoluciones SEREMI e ISP.
4. **Motor de alertas predictivo:** ML para detectar sobreexposición inminente antes de alcanzar límites ICRP.
5. **Mobile-first para inspecciones:** app nativa con captura offline, firma biométrica y geolocalización de hallazgos.
6. **Marketplace de integraciones:** conectores nativos con proveedores dosimétricos (Landauer, Mirion, IRD, DosePro), fabricantes (Siemens, GE, Philips, Varian, Elekta) y sistemas hospitalarios (RIS/PACS/EMR vía HL7/FHIR).
7. **Cumplimiento multi-país por diseño:** motor de reglas configurable por jurisdicción (Chile → Argentina → Perú → Colombia → México → España).
8. **Trazabilidad de blindajes con IA visual:** comparación foto vs. plano DWG para detectar modificaciones no autorizadas.

## 1.4 Sectores y casos de uso

### 1.4.1 Hospitales de alta complejidad
- Gestión integrada de radioterapia, medicina nuclear, imagenología, intervencionismo.
- Reporte trimestral a SEREMI de Salud en 1 clic.
- Integración con RIS/PACS para vincular dosis paciente-trabajador-equipo.

### 1.4.2 Clínicas privadas y centros PET
- Onboarding rápido de personal ocupacionalmente expuesto (POE).
- Trazabilidad radiofármacos: llegada → uso → decaimiento → residuo.

### 1.4.3 Radioterapia (LINAC, braquiterapia)
- QA diario/mensual/anual con checklists digitales.
- Control de fuentes selladas (Ir-192, Co-60) con inventario y decaimiento.

### 1.4.4 Odontología y veterinaria
- Modo "small practice": todo simplificado, autorización de equipos y dosimetría del personal.

### 1.4.5 Industria (gammagrafía, medidores nucleares)
- Gestión de fuentes móviles, permisos de traslado, seguros.
- Trabajadores itinerantes con dosimetría multi-planta.

### 1.4.6 Universidades y laboratorios
- Inventario de fuentes abiertas, licencias por proyecto de investigación.
- Gestión de residuos con decaimiento supervisado.

### 1.4.7 Autoridad regulatoria (SEREMI, ISP, CCHEN)
- Portal de recepción de reportes, licencias, incidentes.
- Panel país agregando estadísticas anonimizadas.

## 1.5 Personas (user personas resumidas)

| Persona | Rol | Necesidad principal | Frecuencia uso |
|---------|-----|---------------------|----------------|
| **Dr. Cortés** | Director Físico Médico | Vista ejecutiva de cumplimiento y auditorías | Semanal |
| **Javiera, OPR** | Oficial Protección Radiológica | Operación diaria: dosimetría, autorizaciones, incidentes | Diaria |
| **Marcelo, técnico QA** | Tecnólogo Médico | Ejecutar y registrar controles de calidad | Diaria |
| **Ing. Rojas** | Ingeniero mantenimiento | Documentar mantenciones y calibraciones | Semanal |
| **Auditor SEREMI** | Fiscalizador | Revisar cumplimiento remoto y programar inspección | Mensual |
| **CFO Hospital** | Finanzas | Costos, contratos con proveedores dosimétricos | Mensual |
| **Trabajador POE** | Personal expuesto | Ver su dosis, licencia, capacitaciones | Semanal |
| **Copilot** | IA embebida | Sugerir, redactar, alertar | Continuo |

---

# 2. Arquitectura funcional

## 2.1 Mapa de dominios (Domain-Driven Design)

Se identifican **12 bounded contexts** con lenguaje ubicuo propio:

```
┌─────────────────────────────────────────────────────────────────┐
│                     RPMS — Bounded Contexts                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. Identity & Access        7. Shielding & Facilities          │
│  2. Workforce (POE)          8. Nuclear Medicine & Sources      │
│  3. Dosimetry                9. Instrumentation & Calibration   │
│  4. Equipment & Assets      10. Incidents & Non-conformities    │
│  5. Document Intelligence   11. Audits & Inspections            │
│  6. Regulatory Compliance   12. AI Copilot & Notifications      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
              ┌────────────────────────────────┐
              │   Cross-cutting: Knowledge      │
              │   Graph + Event Bus + Audit     │
              └────────────────────────────────┘
```

## 2.2 Relación entre dominios

- **Workforce** consume Identity, publica eventos a Dosimetry e Incidents.
- **Dosimetry** consume Workforce y Equipment, publica alertas a Compliance y Copilot.
- **Document Intelligence** es transversal: alimenta a todos los dominios mediante extracción y relación.
- **Regulatory Compliance** es un motor de reglas que evalúa el estado de los otros dominios.
- **AI Copilot** lee todos los dominios (solo lectura + acciones auditadas).

## 2.3 Capacidades funcionales por dominio (matriz L1)

| Dominio | Capacidad L1 |
|---------|-------------|
| Identity | SSO, MFA, RBAC/ABAC, delegación, auditoría de sesión |
| Workforce | Ficha única, historia ocupacional, autorizaciones, licencias, capacitaciones, EPP |
| Dosimetry | Importación multi-proveedor, dosis individual/colectiva, tendencias, alertas ICRP |
| Equipment | Ciclo de vida (adquisición → baja), QA, mantenciones, blindajes asociados |
| Document Intelligence | Ingesta, OCR, clasificación, NER, versionado, firma electrónica, búsqueda semántica |
| Regulatory | Motor de reglas multi-jurisdicción, calendario legal, reportes oficiales |
| Shielding | Planos DWG/PDF, cálculos, inspecciones visuales con IA |
| Nuclear Medicine | Radiofármacos, generadores, actividad, decaimiento, residuos |
| Instrumentation | Inventario, calibraciones, certificados, alertas |
| Incidents | Reporte, investigación (5 whys, Ishikawa), plan de acción, cierre |
| Audits | Programación, checklist, hallazgos, seguimiento |
| AI Copilot | Q&A, redacción, resumen, comparación, detección de faltantes |

---

# 3. Arquitectura técnica

## 3.1 Vista de alto nivel (C4 - Level 1)

```
┌───────────────────────────────────────────────────────────────────┐
│                          USUARIOS                                 │
│  OPR · Trabajador · Auditor · Regulador · Proveedor · Copilot     │
└──────────────────────┬────────────────────────────────────────────┘
                       │ HTTPS · WSS · Mobile · API
                       ▼
┌───────────────────────────────────────────────────────────────────┐
│                    EDGE / CDN / WAF                               │
│           Cloudflare · Azure Front Door · AWS WAF                 │
└──────────────────────┬────────────────────────────────────────────┘
                       ▼
┌───────────────────────────────────────────────────────────────────┐
│                   API GATEWAY (Kong / APIM)                       │
│      Rate limit · Auth · Routing · OpenAPI · mTLS interno         │
└──────────────────────┬────────────────────────────────────────────┘
                       ▼
┌───────────────────────────────────────────────────────────────────┐
│              MICROSERVICIOS (Kubernetes)                          │
│                                                                   │
│  identity-svc  workforce-svc  dosimetry-svc  equipment-svc        │
│  document-svc  shielding-svc  sources-svc    instrumentation-svc  │
│  incident-svc  audit-svc      compliance-svc notification-svc     │
│                                                                   │
│  ai-orchestrator-svc  ocr-svc  embedding-svc  rag-svc             │
└──────┬───────────────────┬──────────────────┬────────────────────┘
       │                   │                  │
       ▼                   ▼                  ▼
┌─────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ PostgreSQL  │  │  Object Storage  │  │ Event Bus        │
│ + pgvector  │  │  S3/MinIO (WORM) │  │ Kafka / Rabbit   │
│ + Timescale │  │                  │  │                  │
└─────────────┘  └──────────────────┘  └──────────────────┘
       │                   │                  │
       ▼                   ▼                  ▼
┌─────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ OpenSearch  │  │  Redis Cluster   │  │  Vault (secrets) │
│ (full-text) │  │  (cache/session) │  │  KMS (crypto)    │
└─────────────┘  └──────────────────┘  └──────────────────┘

Observabilidad transversal: Prometheus · Grafana · Loki · Tempo · OpenTelemetry
```

## 3.2 Stack tecnológico definitivo y justificado

### Frontend

| Componente | Elección | Justificación |
|------------|----------|---------------|
| Framework | **Next.js 15 (App Router)** | SSR/RSC, streaming, mejor Time-to-Interactive, SEO para portal público. |
| Lenguaje | **TypeScript strict** | Contratos tipados end-to-end con backend vía OpenAPI. |
| UI | **shadcn/ui + Radix + Tailwind CSS** | Accesibilidad WCAG 2.2 AA de fábrica, tokens theming (dark/light). |
| Estado | **TanStack Query + Zustand** | Cache HTTP inteligente, estado UI local desacoplado. |
| Formularios | **React Hook Form + Zod** | Validaciones tipadas compartidas con backend. |
| Gráficos | **Recharts + visx** para datos, **D3** para custom | Dashboard ejecutivo profesional. |
| Editor documentos | **TipTap** | Redacción de oficios con IA embebida. |
| PDF viewer | **PDF.js + anotaciones** | Marcado colaborativo sobre documentos. |
| Mobile | **React Native (Expo)** + capa compartida | Inspecciones offline con SQLite local. |
| Testing | **Vitest + Playwright** | Unit + E2E. |

### Backend

| Componente | Elección | Justificación |
|------------|----------|---------------|
| Runtime principal | **.NET 9 (C#)** con arquitectura **hexagonal + CQRS** para servicios de dominio críticos (Dosimetry, Compliance, Equipment) | Rendimiento, tipado fuerte, ecosistema hospitalario maduro, LTS. |
| Runtime IA | **Python 3.12 + FastAPI** para servicios IA/OCR/RAG | Ecosistema ML nativo (LangChain, LlamaIndex, transformers). |
| ORM | **EF Core 9** (.NET) / **SQLAlchemy 2** (Python) | Migraciones versionadas. |
| Autenticación | **Keycloak** (on-prem/cloud) o **Microsoft Entra ID** | OIDC, MFA, federación, SCIM. |
| API | **REST + OpenAPI 3.1** primario, **GraphQL** para dashboard, **gRPC** interno | Contratos claros, herramientas de generación de SDKs. |
| Real-time | **SignalR** (.NET) / **WebSockets** para notificaciones dashboard | Alertas dosimétricas en vivo. |
| Workflow engine | **Elsa Workflows** o **Temporal.io** | Procesos regulatorios de larga duración (autorizaciones, capacitaciones). |
| Motor de reglas | **NRules** (.NET) para compliance | Reglas normativas declarativas y auditables. |

### Datos

| Componente | Elección | Justificación |
|------------|----------|---------------|
| RDBMS principal | **PostgreSQL 16** con extensiones: `pgvector`, `pg_trgm`, `timescaledb`, `pgcrypto`, `postgis` | Vectores para RAG, series temporales para dosimetría, geoespacial para instalaciones. |
| Búsqueda | **OpenSearch 2.x** | Búsqueda full-text multilingüe, sinónimos técnicos, agregaciones rápidas. |
| Cache | **Redis 7 Cluster** | Sesiones, resultados de búsqueda, rate limiting. |
| Object storage | **S3 / Azure Blob / MinIO** con **Object Lock (WORM)** para documentos oficiales | Cumplimiento retención legal. |
| Data warehouse | **ClickHouse** o **Databricks Delta Lake** (fase 3) | Analítica y BI de flotas. |
| Grafo | **Neo4j** o **Apache AGE sobre PostgreSQL** | Motor de relaciones (Trabajador↔Equipo↔Documento). |

### Mensajería y procesos asincrónicos

| Componente | Elección | Justificación |
|------------|----------|---------------|
| Broker | **Apache Kafka** (cloud managed: Confluent, MSK, Event Hubs) | Event sourcing, alta throughput, retención configurable. |
| Alternativa MVP | **RabbitMQ** | Menor complejidad operativa en fase inicial. |
| Scheduler | **Hangfire** (.NET) / **Celery Beat** (Python) | Recordatorios 90/60/30/15/7/1 día. |

### IA/ML

| Componente | Elección | Justificación |
|------------|----------|---------------|
| LLM primario | **Claude Sonnet/Opus vía API** para Copilot | Razonamiento, redacción regulatoria en español, contexto largo. |
| LLM alternativo/local | **Llama 3.3 70B** o **Qwen 2.5** vía **vLLM** on-prem | Requisitos de soberanía de datos. |
| Embeddings | **text-embedding-3-large** (OpenAI) o **bge-m3** (open source multilingüe) | Multilingüe, soporta español técnico. |
| Reranker | **Cohere Rerank v3** o **bge-reranker-v2** | Precisión en RAG. |
| OCR básico | **Tesseract 5** con modelos entrenados | Base gratuita. |
| OCR avanzado | **Azure Document Intelligence** o **Google Document AI** | Documentos complejos: tablas, formularios, sellos. |
| OCR fallback IA | **Claude Vision** o **GPT-4o Vision** | Documentos manuscritos, sellos borrosos. |
| Visión (blindajes) | **YOLOv10 + SAM 2** | Detección de modificaciones foto vs. plano. |
| Framework RAG | **LlamaIndex + LangGraph** | Orquestación de agentes. |
| Vector store | **pgvector** (integrado) + **Qdrant** para volúmenes altos | Coste-beneficio. |

### Infraestructura

| Componente | Elección | Justificación |
|------------|----------|---------------|
| Contenedores | **Docker + Kubernetes (EKS/AKS/GKE)** | Portabilidad multi-cloud. |
| IaC | **Terraform + Terragrunt** | Reproducibilidad. |
| GitOps | **ArgoCD** o **Flux** | Despliegues declarativos. |
| Service mesh | **Istio** o **Linkerd** (fase 2+) | mTLS, observabilidad, tráfico canary. |
| Secretos | **HashiCorp Vault** + **KMS del cloud** | Cifrado de PII y sobre dosimetría. |
| CI/CD | **GitHub Actions** o **Azure DevOps** | Pipelines de build, test, scan, deploy. |
| Observabilidad | **OpenTelemetry** → **Prometheus + Grafana + Loki + Tempo** | Full stack O11y. |
| Errores | **Sentry** | Tracking de errores frontend/backend. |

### Integraciones

| Componente | Estándar |
|------------|----------|
| Sistemas clínicos | HL7 v2, HL7 FHIR R5, DICOM (metadata dosis) |
| Identidad corporativa | SAML 2.0, OIDC, LDAP/AD, SCIM |
| Correo | SMTP + Microsoft Graph + Gmail API |
| Mensajería usuario | WhatsApp Business API, Twilio SMS, FCM/APNS |
| Firma electrónica | eIDAS/FirmaGob Chile, DocuSign, ClickSign |
| Autoridades | API REST con SEREMI (cuando exista), envío S/MIME hasta entonces |

## 3.3 Arquitectura hexagonal por microservicio (patrón)

Cada microservicio sigue **Ports & Adapters + CQRS ligero**:

```
┌────────────────────────────────────────────────────┐
│              [ Domain Core ]                       │
│  Entities · Value Objects · Domain Services        │
│  Domain Events · Aggregates · Invariants           │
└────────────────────────────────────────────────────┘
              ▲                    ▲
              │ Ports              │ Ports
              │ (Interfaces)       │
    ┌─────────┴────────┐  ┌────────┴──────────┐
    │  Application     │  │  Application       │
    │  (Commands)      │  │  (Queries)         │
    └─────────┬────────┘  └────────┬───────────┘
              │                    │
      ┌───────┴────────────────────┴────────┐
      │           Adapters                  │
      │  REST · gRPC · Kafka · SQL · S3     │
      └─────────────────────────────────────┘
```

## 3.4 Estrategia multi-tenant

- **Modelo:** Silo por defecto (schema-per-tenant en PostgreSQL) + Pool para tenants pequeños (tabla `tenant_id` con RLS).
- **Aislamiento fuerte:** Row-Level Security (RLS) obligatorio en todas las tablas.
- **Personalización por tenant:** feature flags (Unleash/LaunchDarkly), branding, jurisdicción normativa.
- **Data residency:** región de despliegue por país (Chile → São Paulo, Santiago; UE → Frankfurt).

## 3.5 Presupuesto de rendimiento (SLO)

| Operación | P95 | P99 |
|-----------|-----|-----|
| Login (con MFA) | 800 ms | 1.5 s |
| Dashboard carga inicial | 900 ms | 1.8 s |
| Búsqueda universal | 400 ms | 900 ms |
| Consulta Copilot (respuesta parcial streaming) | 1.2 s | 2.5 s |
| Upload + OCR + clasificación (async) | 30 s | 90 s |
| Importación lote dosimétrico (10k trabajadores) | 5 min | 12 min |
| Generación reporte regulatorio | 8 s | 20 s |
| Disponibilidad plataforma | 99.9% | — |

---

# 4. Modelo de datos (ERD lógico)

## 4.1 Vista de alto nivel

El modelo se organiza en 8 agrupaciones lógicas. Se muestra un ERD simplificado:

```
                     ┌────────────────┐
                     │    Tenant      │
                     └────────┬───────┘
                              │ 1..n
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
  ┌──────────┐         ┌───────────┐          ┌──────────┐
  │  User    │◄────────│ Facility  │─────────►│  Service │
  └────┬─────┘         └─────┬─────┘          └────┬─────┘
       │                     │                     │
       │                     ▼                     │
       │              ┌──────────────┐             │
       │              │    Room      │             │
       │              └──────┬───────┘             │
       │                     │                     │
       ▼                     ▼                     ▼
  ┌──────────┐         ┌──────────┐          ┌──────────┐
  │  Worker  │────────►│Equipment │◄─────────│Instrument│
  │  (POE)   │◄────────┤          │          │          │
  └────┬─────┘  m..n   └────┬─────┘          └────┬─────┘
       │                    │                     │
       │                    ▼                     │
       │             ┌──────────────┐             │
       │             │  Shielding   │             │
       │             └──────────────┘             │
       ▼
  ┌──────────────┐    ┌────────────────┐    ┌─────────────┐
  │ Dosimeter    │───►│ DoseReading    │    │ Calibration │
  └──────┬───────┘    │  (Timescale)   │    └─────────────┘
         │            └────────────────┘
         │
         ▼
  ┌──────────────┐
  │ Authorization│─────► License ─────► Training ─────► MedicalExam
  └──────────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  Document        │◄─────── extractedEntities
                    │  (versioned)     │
                    └────────┬─────────┘
                             │
                             ▼
                    ┌──────────────────┐
                    │  DocumentChunk   │  (embedding vector)
                    └──────────────────┘

  ┌───────────┐    ┌───────────┐    ┌──────────┐
  │ Incident  │    │  Audit    │    │ Waste    │
  └───────────┘    └───────────┘    └──────────┘

  ┌────────────────────────────────────────────────┐
  │  KnowledgeGraph.Edges                          │
  │  (relaciones tipadas entre cualquier entidad)  │
  └────────────────────────────────────────────────┘
```

## 4.2 Entidades núcleo (definiciones esenciales)

### 4.2.1 Tenant
- `id (UUID)`, `name`, `country_code`, `jurisdiction_profile_id`, `plan`, `data_region`, `created_at`, `status`.

### 4.2.2 User (identidad de plataforma)
- `id`, `tenant_id`, `email`, `phone`, `identity_provider_sub`, `mfa_enabled`, `roles[]`, `last_login_at`, `status`.

### 4.2.3 Worker (POE — persona ocupacionalmente expuesta)
- `id`, `tenant_id`, `national_id (RUT)`, `full_name`, `birth_date`, `sex`, `photo_url`, `signature_url`, `profession`, `job_title`, `category` (A/B según ICRP), `primary_facility_id`, `primary_service_id`, `hire_date`, `status`, `qr_token`.
- **Unicidad:** `(tenant_id, national_id)` UNIQUE.

### 4.2.4 Facility / Service / Room
- Facility: `id`, `tenant_id`, `name`, `address`, `geo_point`, `type` (hospital, clínica, industrial, académica, veterinaria).
- Service: `id`, `facility_id`, `name` (Radioterapia, Medicina Nuclear...), `head_worker_id`.
- Room: `id`, `service_id`, `code`, `name`, `type` (bunker, sala CT, sala PET, sala fuentes), `floor`, `area_m2`.

### 4.2.5 Equipment
- `id`, `tenant_id`, `type` (LINAC, CT, PET, PET/CT, PET/MR, Mammo, Fluoro, IR, MRI, DEXA, Gammacamera, SPECT, Brachy, X-ray dental, industrial radiography...), `manufacturer`, `model`, `serial_number`, `installation_date`, `commissioning_date`, `room_id`, `status` (activo, en mantención, fuera de servicio, dado de baja), `firmware_version`, `provider_id`.

### 4.2.6 Dosimeter y DoseReading
- Dosimeter: `id`, `worker_id`, `type` (TLD, OSL, EPD, active), `provider`, `code`, `location` (cuerpo entero, cristalino, extremidad), `issued_at`, `returned_at`, `status`.
- DoseReading (hipertabla Timescale): `time`, `dosimeter_id`, `worker_id`, `hp10_msv`, `hp007_msv`, `hp3_msv`, `neutron_msv`, `provider_report_id`, `period_start`, `period_end`, `is_anomaly`, `anomaly_reason`.
- Se calcula agregado `WorkerDoseSummary` mensual, anual y 5-anual (para límite ICRP 100 mSv/5 años).

### 4.2.7 Authorization / License / Training
- Authorization: `id`, `worker_id`, `type` (operador, OPR, físico médico), `issued_by`, `issued_at`, `expires_at`, `document_id`, `scope[]`.
- License: `id`, `subject_type` (worker | equipment | facility), `subject_id`, `type`, `number`, `issued_by`, `expires_at`, `document_id`.
- Training: `id`, `worker_id`, `course_name`, `hours`, `date`, `certificate_document_id`, `next_renewal_at`.

### 4.2.8 Shielding
- `id`, `room_id`, `material` (Pb, hormigón, baritado), `thickness_mm`, `wall` (N, S, E, O, techo, piso, puerta, ventana), `design_document_id` (DWG/PDF), `calculation_document_id`, `photos[]`, `last_inspection_at`.

### 4.2.9 RadioactiveSource / Radiopharmaceutical
- Source: `id`, `isotope`, `type` (sellada, abierta), `activity_bq_initial`, `activity_date`, `half_life_days`, `serial`, `location_room_id`, `status` (en uso, decaimiento, residuo, dispuesta).
- Radiopharmaceutical: `id`, `name` (Tc-99m MDP, F-18 FDG...), `batch`, `activity_bq`, `calibration_datetime`, `received_at`, `supplier`, `linked_studies[]`.

### 4.2.10 Instrument
- `id`, `type` (dosímetro personal lectura, contaminómetro, monitor área, cámara de ionización, activímetro...), `manufacturer`, `model`, `serial`, `owner_service_id`, `last_calibration_at`, `next_calibration_at`, `certificate_document_id`, `qr_token`.

### 4.2.11 Incident
- `id`, `severity` (INES 0-7 o interno L1-L5), `type`, `date_time`, `location_room_id`, `equipment_id`, `workers_involved[]`, `narrative`, `root_cause` (5whys/ishikawa JSON), `corrective_actions[]`, `status`, `notified_authority_at`.

### 4.2.12 Audit
- `id`, `scope`, `type` (interna, externa, regulatoria), `date`, `auditor`, `findings[]`, `action_plan_id`, `status`.

### 4.2.13 Document
- `id`, `tenant_id`, `original_filename`, `sha256`, `size_bytes`, `mime_type`, `storage_uri`, `document_type` (auto-clasificado), `version`, `parent_document_id`, `worm_locked`, `uploaded_by`, `uploaded_at`, `ocr_status`, `extracted_metadata (JSONB)`, `related_entities (JSONB)`.
- Cada documento tiene `DocumentChunk` con `text`, `embedding (vector(1024))`, `page`, `bbox`.

### 4.2.14 KnowledgeEdge (motor de relaciones)
- `id`, `source_type`, `source_id`, `target_type`, `target_id`, `relation` (owns, operates, calibrated_by, expires_on, references, occurred_at), `weight`, `metadata (JSONB)`, `discovered_by` (rule|ai|user), `discovered_at`.

## 4.3 Diccionario de tipos documentales (clasificación automática)

Ejemplo (extensible por tenant):

| Código | Tipo |
|--------|------|
| DT001 | Certificado de calibración instrumento |
| DT002 | Informe dosimétrico mensual |
| DT003 | Autorización de operación (SEREMI) |
| DT004 | Licencia de instalación |
| DT005 | Plano de blindaje |
| DT006 | Memoria de cálculo blindaje |
| DT007 | Certificado curso protección radiológica |
| DT008 | Examen ocupacional |
| DT009 | Informe de incidente |
| DT010 | Reporte QA equipo |
| DT011 | Certificado de fuente |
| DT012 | Guía de despacho radiofármaco |
| DT013 | Acta inspección regulatoria |
| DT014 | Manual/firmware equipo |
| DT015 | Contrato proveedor |
| ... | ... |

---

# 5. Diseño de la base de datos

## 5.1 Principios

1. **PostgreSQL 16 como fuente de verdad** (OLTP).
2. **Extensiones activas:** `pgvector` (RAG), `pg_trgm` (fuzzy search), `timescaledb` (dosimetría time-series), `pgcrypto` (cifrado columnar), `postgis` (geolocalización), `pg_partman` (particionamiento), `pgaudit` (auditoría).
3. **Row-Level Security (RLS)** en todas las tablas con `tenant_id`.
4. **Auditoría** por tabla via *triggers* → `audit.log` (append-only, WORM en el bucket).
5. **Idempotencia**: toda operación importante recibe `idempotency_key`.

## 5.2 Ejemplo: DDL de tablas críticas

```sql
-- Multi-tenant guard
CREATE SCHEMA rpms;

CREATE TABLE rpms.tenant (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  country_code CHAR(2) NOT NULL,
  jurisdiction_profile_id UUID NOT NULL,
  plan TEXT NOT NULL,
  data_region TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Workers
CREATE TABLE rpms.worker (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES rpms.tenant(id),
  national_id TEXT NOT NULL,
  full_name TEXT NOT NULL,
  birth_date DATE,
  sex CHAR(1),
  photo_url TEXT,
  signature_url TEXT,
  profession TEXT,
  job_title TEXT,
  icrp_category CHAR(1) CHECK (icrp_category IN ('A','B')),
  primary_facility_id UUID,
  primary_service_id UUID,
  hire_date DATE,
  status TEXT NOT NULL DEFAULT 'active',
  qr_token TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, national_id)
);

ALTER TABLE rpms.worker ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON rpms.worker
  USING (tenant_id = current_setting('rpms.current_tenant')::uuid);

-- Dosimetría time-series
CREATE TABLE rpms.dose_reading (
  time TIMESTAMPTZ NOT NULL,
  tenant_id UUID NOT NULL,
  worker_id UUID NOT NULL,
  dosimeter_id UUID NOT NULL,
  hp10_msv NUMERIC(9,4),
  hp007_msv NUMERIC(9,4),
  hp3_msv NUMERIC(9,4),
  neutron_msv NUMERIC(9,4),
  provider_report_id UUID,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  is_anomaly BOOLEAN DEFAULT FALSE,
  anomaly_reason TEXT
);
SELECT create_hypertable('rpms.dose_reading', 'time');

CREATE INDEX ix_dose_worker_time ON rpms.dose_reading (worker_id, time DESC);
CREATE INDEX ix_dose_tenant_time ON rpms.dose_reading (tenant_id, time DESC);

-- Documentos + embeddings
CREATE TABLE rpms.document (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  original_filename TEXT NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT NOT NULL,
  mime_type TEXT NOT NULL,
  storage_uri TEXT NOT NULL,
  document_type TEXT,
  version INT NOT NULL DEFAULT 1,
  parent_document_id UUID,
  worm_locked BOOLEAN DEFAULT FALSE,
  uploaded_by UUID NOT NULL,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ocr_status TEXT NOT NULL DEFAULT 'pending',
  extracted_metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  related_entities JSONB NOT NULL DEFAULT '[]'::jsonb,
  UNIQUE (tenant_id, sha256)
);
CREATE INDEX ix_doc_meta_gin ON rpms.document USING GIN (extracted_metadata);
CREATE INDEX ix_doc_rel_gin ON rpms.document USING GIN (related_entities);

CREATE TABLE rpms.document_chunk (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  document_id UUID NOT NULL REFERENCES rpms.document(id) ON DELETE CASCADE,
  page INT,
  bbox JSONB,
  text TEXT NOT NULL,
  embedding VECTOR(1024) NOT NULL
);
CREATE INDEX ix_chunk_embedding ON rpms.document_chunk
  USING hnsw (embedding vector_cosine_ops);
CREATE INDEX ix_chunk_text_trgm ON rpms.document_chunk
  USING GIN (text gin_trgm_ops);

-- Grafo de conocimiento
CREATE TABLE rpms.knowledge_edge (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  source_type TEXT NOT NULL,
  source_id UUID NOT NULL,
  target_type TEXT NOT NULL,
  target_id UUID NOT NULL,
  relation TEXT NOT NULL,
  weight NUMERIC(5,3) DEFAULT 1.0,
  metadata JSONB DEFAULT '{}'::jsonb,
  discovered_by TEXT NOT NULL CHECK (discovered_by IN ('rule','ai','user')),
  discovered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tenant_id, source_type, source_id, target_type, target_id, relation)
);
CREATE INDEX ix_edge_src ON rpms.knowledge_edge (tenant_id, source_type, source_id);
CREATE INDEX ix_edge_tgt ON rpms.knowledge_edge (tenant_id, target_type, target_id);
```

## 5.3 Estrategia de particionamiento y retención

- **dose_reading**: hypertable Timescale, chunk 1 mes, retención 30 años (obligación legal).
- **audit_log**: partición mensual por `time`, retención 10 años.
- **document**: sin partición pero WORM en storage por 10 años mínimo.
- **document_chunk**: reindexación HNSW nocturna incremental.

## 5.4 Índices críticos para <500 ms P95

- BRIN en `time` para tablas históricas.
- HNSW en embeddings.
- GIN sobre JSONB de metadata.
- Trigram para fuzzy search de nombres/RUT.
- Índices parciales para `status='active'`.

## 5.5 Estrategia de backup y DR

- **RPO ≤ 5 min**: WAL streaming a bucket cifrado + PITR.
- **RTO ≤ 30 min**: standby en región alterna, promoción automatizada.
- **Backups lógicos:** `pg_dump` semanal + retención 12 meses.
- **Pruebas de restore trimestrales** con reporte firmado.

---

# 6. Módulos y submódulos

## 6.1 Mapa modular

```
RPMS
├── 01. Dashboard Ejecutivo
├── 02. Trabajadores (POE)
│   ├── 2.1 Ficha única
│   ├── 2.2 Autorizaciones
│   ├── 2.3 Licencias
│   ├── 2.4 Capacitaciones
│   ├── 2.5 Historia médica ocupacional
│   ├── 2.6 EPP
│   └── 2.7 Portal del trabajador
├── 03. Dosimetría
│   ├── 3.1 Configuración proveedor
│   ├── 3.2 Ingesta automática
│   ├── 3.3 Historial y tendencias
│   ├── 3.4 Anomalías IA
│   ├── 3.5 Reportes regulatorios
│   └── 3.6 Dosimetría interna (WBC / bioensayo)
├── 04. Equipos
│   ├── 4.1 Inventario
│   ├── 4.2 QA (diario/mensual/anual)
│   ├── 4.3 Mantenciones
│   ├── 4.4 Documentación técnica
│   └── 4.5 Ciclo de vida
├── 05. Blindajes e Instalaciones
│   ├── 5.1 Planos y cálculos
│   ├── 5.2 Inspecciones visuales
│   └── 5.3 Detección IA de cambios
├── 06. Medicina Nuclear y Fuentes
│   ├── 6.1 Radiofármacos
│   ├── 6.2 Fuentes selladas
│   ├── 6.3 Fuentes abiertas
│   ├── 6.4 Generadores
│   ├── 6.5 Decaimiento
│   └── 6.6 Residuos radiactivos
├── 07. Instrumentación y Calibraciones
├── 08. Incidentes y No Conformidades
├── 09. Auditorías e Inspecciones
├── 10. Gestión Documental Inteligente
│   ├── 10.1 Bandeja de entrada
│   ├── 10.2 OCR + Clasificación
│   ├── 10.3 Extracción NER
│   ├── 10.4 Validación humana
│   ├── 10.5 Versionado y firma
│   └── 10.6 Búsqueda semántica
├── 11. Cumplimiento Regulatorio
│   ├── 11.1 Motor de reglas
│   ├── 11.2 Calendario legal
│   ├── 11.3 Reportes oficiales
│   └── 11.4 Interlocución con autoridad
├── 12. Copilot IA
│   ├── 12.1 Preguntas en lenguaje natural
│   ├── 12.2 Redacción asistida (oficios, memos)
│   ├── 12.3 Comparación documental
│   ├── 12.4 Detección de faltantes
│   └── 12.5 Agentes autónomos supervisados
├── 13. Reportes y Analítica
├── 14. Notificaciones y Automatización
├── 15. Integraciones y Marketplace
├── 16. Administración y Seguridad
└── 17. Portal Regulador (vista fiscalizador)
```

## 6.2 Detalle: Gestión Documental Inteligente (módulo bandera)

Este módulo merece descripción extensa por ser el diferenciador central.

### 6.2.1 Flujo de ingesta

```
Upload (drag&drop | email | scanner | API | mobile capture)
   │
   ▼
[Virus scan] → ClamAV / Defender
   │
   ▼
[Deduplicación] SHA-256 → si ya existe, versionar
   │
   ▼
[Extracción texto]
   ├─ PDF nativo: PyMuPDF
   ├─ PDF escaneado: Tesseract → fallback Azure Doc Intelligence
   ├─ DOCX/XLSX: python-docx / openpyxl
   ├─ Imagen: Vision LLM
   └─ Email .eml/.msg: extract-msg + adjuntos
   │
   ▼
[Clasificación tipo documental]
   ├─ Zero-shot con LLM + few-shot ejemplos del tenant
   └─ Modelo fine-tuned (fase 2) sobre tipos DT001–DTNNN
   │
   ▼
[NER + extracción entidades]
   ├─ Prompt estructurado con JSON schema por tipo documental
   ├─ Validación: RUT (mod 11), fechas, formatos oficiales
   └─ Salida: {rut, nombre, equipo, serie, resolución, fecha, ...}
   │
   ▼
[Vinculación grafo]
   ├─ Match difuso (trigram) contra Workers, Equipment, Facilities
   ├─ Score de confianza
   ├─ Auto-vinculación si score ≥ 0.92
   └─ Cola de revisión humana si 0.70 ≤ score < 0.92
   │
   ▼
[Chunking + embeddings]
   ├─ Chunk semántico (semantic chunker)
   ├─ Embedding bge-m3 / text-embedding-3-large
   └─ Insert pgvector
   │
   ▼
[Indexación búsqueda]
   ├─ OpenSearch (full-text + facets)
   └─ pgvector (semántica)
   │
   ▼
[Notificación]
   └─ "Nuevo documento clasificado como Certificado de Calibración
        del contaminómetro Ludlum Model 3 (S/N 45678). Vence 2027-04-12.
        Revisar y confirmar."
```

### 6.2.2 Validación humana (Human-in-the-Loop)

- UI de tres paneles: **PDF anotado** | **Campos extraídos editables** | **Entidades relacionadas sugeridas**.
- Botón "**Confirmar y aprender**" → marca gold sample, alimenta fine-tuning periódico.
- Métricas visibles: precisión clasificación, precisión NER por campo.

### 6.2.3 Versionado y firma

- Cada modificación crea una nueva versión inmutable.
- Firma electrónica avanzada (eIDAS/FEA Chile) opcional por tipo documental.
- Sello de tiempo TSA para documentos regulatorios.
- WORM (Object Lock) en documentos oficiales.

### 6.2.4 Búsqueda universal (Command Bar `⌘K`)

Barra única inspirada en Linear/Notion:

- Ranking híbrido: BM25 (OpenSearch) + coseno (pgvector) + boost por recency y relevancia del tenant.
- Filtros facetados: tipo, fecha, servicio, entidad relacionada.
- Preview inline sin abrir documento.
- Atajos: `t:` tipo, `e:` equipo, `w:` trabajador, `v:` vence antes de.

## 6.3 Detalle: Dosimetría

### 6.3.1 Ingesta multi-proveedor

Adaptadores por proveedor (Landauer, Mirion Instadose, IRD, DosePro, Global Dosimetry, etc.):

- **Watcher email** (IMAP dedicado) descarga adjuntos automáticamente.
- **SFTP** con credenciales por proveedor.
- **API REST** cuando exista.
- **Upload manual** con auto-detección de formato.

Parser inteligente:
- Detecta cabeceras (RUT/nombre/dosímetro/dosis/período).
- Reconcilia trabajadores existentes con match difuso + validación humana.
- Rechaza y aísla filas anómalas (dosis > 20 mSv/mes, valores negativos, códigos no vinculados).

### 6.3.2 Anomalías (motor ML)

- Baseline por trabajador y por rol (mediana móvil 12 meses).
- Detector: Isolation Forest + reglas heurísticas.
- Umbrales configurables por tenant:
  - Investigación individual: >0.5 × límite anual (ICRP: 20 mSv → alerta 10 mSv).
  - Dosis inesperada Categoría B (>1 mSv/mes).
  - Dosis nula continua ("dosímetro no usado") — patrón de olvido.

### 6.3.3 Cálculos automáticos

- Dosis acumulada rolling (mes, año, 5 años).
- Proyección lineal a fin de año con IC 95%.
- Comparación grupo par (percentil dentro del servicio).
- Cálculo de límite ICRP 60/103 aplicado a la jurisdicción del tenant.

## 6.4 Detalle: Cumplimiento Regulatorio

### 6.4.1 Motor de reglas (Chile, ejemplo)

Reglas declarativas YAML (compiladas a NRules):

```yaml
- id: CL-DS133-EQUIPO-AUTORIZACION
  jurisdiction: CL
  when:
    - entity: Equipment
      condition: emits_ionizing_radiation == true
    - not_exists:
        entity: License
        where: subject_id == Equipment.id AND type == 'operation'
  then:
    severity: critical
    message: "Equipo {{Equipment.model}} S/N {{Equipment.serial}} requiere autorización de operación (DS 133/1984)."
    action: create_task
    assignee_role: OPR

- id: CL-DS3-DOSIMETRO-MENSUAL
  jurisdiction: CL
  when:
    - entity: Worker
      condition: icrp_category == 'A'
    - not_exists:
        entity: DoseReading
        where: worker_id == Worker.id AND period covers last_month
  then:
    severity: high
    message: "Trabajador categoría A sin lectura dosimétrica del mes {{last_month}}."
    action: notify
```

### 6.4.2 Calendario legal

- Vista tipo Notion Calendar con todas las obligaciones (reportes trimestrales, renovaciones, capacitaciones periódicas).
- Alertas escalonadas 90/60/30/15/7/1 día por múltiples canales.
- Delegación de responsables.

### 6.4.3 Reportes oficiales

Templates versionados con placeholders. Ejemplo estructura para Chile:

- Formulario de comunicación de dosis a autoridad.
- Reporte anual de instalación radiactiva.
- Inventario de fuentes.
- Comunicación de incidentes.

Generados en 1 clic → PDF firmado + XML/JSON estructurado (cuando la autoridad lo soporte).

---

# 7. Flujos de trabajo (workflows clave)

## 7.1 Onboarding de nuevo Trabajador POE

```
1. OPR crea Worker → sistema pide solo RUT + nombre + servicio
2. Sistema busca duplicados nacional (evita crear persona ya existente)
3. Genera QR único
4. Solicita foto y firma (webcam/mobile) — opcional en el momento
5. Copilot sugiere:
   ├─ Autorización de operación pendiente (según equipo del servicio)
   ├─ Capacitación básica requerida (según normativa chilena)
   ├─ Examen ocupacional inicial
   └─ Asignación de dosímetro
6. Al confirmar cada sugerencia, se generan tareas con vencimientos
7. Se envía email al trabajador con link al portal personal
8. Estado: "En incorporación" hasta que todos los ítems estén completos
9. Automáticamente pasa a "Activo autorizado"
```

## 7.2 Recepción de reporte dosimétrico mensual

```
1. Watcher SFTP detecta archivo del proveedor (Landauer)
2. Parser identifica: 47 trabajadores, período 2026-06
3. Match automático: 45 trabajadores reconciliados, 2 con score bajo
4. Sistema aísla los 2 casos en cola de validación
5. Cálculos:
   ├─ Acumulados mensuales, anuales, quinquenales
   ├─ Comparación vs. baseline personal
   ├─ Detección anomalías: 1 caso >0.5 × límite mensual
6. Alerta al OPR: "1 anomalía detectada, 2 registros requieren revisión"
7. Reporte automático generado y guardado
8. Copilot pre-redacta oficio de comunicación a autoridad si aplica
9. Todos los trabajadores ven su lectura en portal personal
```

## 7.3 Subida y procesamiento de documento

```
Usuario arrastra "Certificado_Calibracion_Ludlum_2026.pdf"
   │
   ▼
Toast: "Documento recibido, procesando…"
   │
   ▼ (segundos)
Toast: "Detecté que es un Certificado de Calibración del Contaminómetro
        Ludlum Model 3 (S/N 45678), emitido por MetLab, vigencia 2028-04-12.
        [Ver] [Confirmar] [Corregir]"
   │
   ├─► Usuario confirma → sistema actualiza el instrumento, registra la
   │                        próxima calibración, notifica al responsable.
   │
   └─► Usuario corrige → alimenta modelo de aprendizaje continuo.
```

## 7.4 Ciclo de vida de un incidente

```
Reporte
   ├─ Web / mobile con fotos y geolocalización
   ├─ Copilot pregunta: "¿Hay personas involucradas? ¿Qué fuente/equipo?"
   ▼
Clasificación INES o escala interna
   ▼
Notificación automática a OPR + Dirección + (si aplica) autoridad
   ▼
Investigación
   ├─ Timeline reconstruida con datos del sistema (dosis, ubicación, permisos)
   ├─ Templates 5 whys / Ishikawa asistidos por IA
   ▼
Plan de acción con responsables y plazos
   ▼
Seguimiento hasta cierre
   ▼
Lecciones aprendidas → base de conocimiento consultable
```

## 7.5 Auditoría regulatoria

```
Regulador solicita acceso temporal → se emite rol read-only con vigencia
   ▼
Portal Regulador muestra vista curada:
   ├─ Cumplimiento por servicio (semáforo)
   ├─ Documentos verificables por hash público
   ├─ Trazabilidad de dosis
   ├─ Incidentes reportados
   ▼
Regulador solicita evidencia adicional → OPR responde desde chat interno
   ▼
Cierre y bitácora firmada
```

---

# 8. Wireframes y diseño UX/UI

## 8.1 Sistema de diseño

- **Design tokens** (definidos en Tailwind config + CSS variables):
  - Colores base: neutrales cálidos (zinc) + acento único por producto (`#3B82F6` en claro, `#60A5FA` en oscuro).
  - Colores semánticos: `success #10B981`, `warning #F59E0B`, `danger #EF4444`, `info #3B82F6`.
  - Tipografía: **Inter** para UI + **JetBrains Mono** para códigos y datos numéricos.
  - Radios: 6/8/12/16 px.
  - Sombras: 3 niveles muy sutiles.
- **Grid:** 12 columnas, 8px baseline.
- **Densidad:** dos modos — cómodo (default) y compacto (para OPRs poder).
- **Modo oscuro:** primer ciudadano; se diseña en oscuro y se adapta a claro.
- **Accesibilidad:** WCAG 2.2 AA verificado en CI (axe-core).

## 8.2 Layout principal

```
┌────────────────────────────────────────────────────────────────┐
│  ⌘K Buscar…                              🔔 3  · Copilot ⌥·  👤│  (topbar 56px)
├─────┬──────────────────────────────────────────────────────────┤
│     │                                                          │
│  🏠 │                                                          │
│  👥 │              CONTENIDO PRINCIPAL                          │
│  📻 │        (dashboard, tablas, detalles)                      │
│  🩻 │                                                          │
│  📄 │                                                          │
│  ⚠️  │                                                          │
│  📊 │                                                          │
│  ⚙️  │                                                          │
│     │                                                          │
└─────┴──────────────────────────────────────────────────────────┘
  Sidebar 68px (collapsable a rail 44 px)
```

- Sidebar minimalista con iconos + tooltips.
- Command bar universal siempre a `⌘K`.
- Panel lateral derecho (drawer) para Copilot, siempre a un clic.

## 8.3 Wireframes clave (descripción)

### 8.3.1 Ficha del trabajador

```
┌──────────────────────────────────────────────────────────────┐
│ ← Javiera Muñoz (17.245.892-3)             ▼ Acciones  · ⋯   │
├───────────────────────────────────────────────┬──────────────┤
│  [Foto]  Físico Médico · Radioterapia         │  QR          │
│          Cat. A · Activa · Contrato indefinido│ ▓▓▓▓▓        │
│                                                │ ▓▓▓▓▓        │
├──────────┬──────────┬──────────┬──────────┬───┴──────┬──────┤
│ Resumen  │ Dosimetría│ Autoriz. │ Capacitac.│ Incidentes│Docs.│
├──────────┴──────────┴──────────┴──────────┴──────────┴──────┤
│                                                              │
│  Dosis últimos 12m (Hp10):  ▁▂▂▃▂▃▃▂▂▄▃▃  = 3.2 mSv           │
│  Acumulado 2026: 3.2 mSv   |  5-anual: 18.4 mSv  ✓            │
│                                                              │
│  Autorizaciones           Vence     Estado                    │
│  · Op. LINAC #4571        2027-03   ✓ Vigente                 │
│  · OPR                    2026-08   ⚠ Renovar (60 d)          │
│                                                              │
│  Próximas acciones (auto)                                     │
│  · Examen ocupacional bienal en 42 días                       │
│  · Curso de recertificación en 7 meses                        │
│                                                              │
│  🤖 Copilot: "Todo en orden. La renovación de OPR requiere    │
│      curso de 40 h — quedan 2 cupos en curso del 12/08. ¿Reservar?"│
└──────────────────────────────────────────────────────────────┘
```

### 8.3.2 Ingesta documental

```
┌──────────────────────────────────────────────────────────────┐
│  Bandeja de documentos                                        │
├──────────────────────────────────────────────────────────────┤
│  ⬆ Subir  ·  📥 Email  ·  🖨 Scanner  ·  🔗 Integración        │
│                                                              │
│  Filtro: [Todos] [Sin clasificar 3] [Pendiente confirmar 7]   │
├──────────────────────────────────────────────────────────────┤
│  📄 Certificado_QA_CT_Siemens.pdf     hace 2 min              │
│      → Certificado QA · CT Somatom · SN 87334 · vence 2027-06 │
│      [Ver] [Confirmar] [Corregir]                             │
│                                                              │
│  📄 informe_dosimetria_junio.xlsx     hace 12 min             │
│      → Reporte mensual · 47 trabajadores · 1 anomalía         │
│      [Ver] [Confirmar]                                        │
└──────────────────────────────────────────────────────────────┘
```

### 8.3.3 Panel Copilot (drawer derecho)

```
┌───────────────────────────┐
│  🤖 Copilot          ─ ×  │
├───────────────────────────┤
│                           │
│  Sugerencias              │
│  • 3 dosímetros no        │
│    devueltos hace 45 d    │
│  • Recert. curso OPR      │
│    caduca para 2 personas │
│  • Preparar reporte Q3    │
│                           │
├───────────────────────────┤
│  Preguntar en lenguaje    │
│  natural…                 │
│  [__________________]  ↵  │
└───────────────────────────┘
```

## 8.4 Micro-interacciones

- Toasts contextuales no invasivos (esquina inferior derecha, 4 s).
- Optimistic UI para acciones frecuentes.
- Motion sutil (`framer-motion`): entradas 200 ms, salidas 150 ms.
- Skeleton screens en lugar de spinners.
- Empty states con Copilot ofreciendo la siguiente acción.

## 8.5 Mobile

- App nativa (Expo/React Native) enfocada en:
  - Inspecciones y auditorías offline.
  - Escaneo QR (equipos, dosímetros, fuentes).
  - Captura de fotos con anotación.
  - Firma biométrica.
  - Notificaciones push.
- Sincronización eventual con CRDT/Yjs para trabajos colaborativos en terreno.

---

# 9. Diseño del dashboard ejecutivo

## 9.1 Objetivo

En **una pantalla y sin scroll** en desktop 1440×900, el usuario ve el pulso completo de protección radiológica. Es el 90 % de la información crítica en 3 segundos.

## 9.2 Layout propuesto

```
┌────────────────────────────────────────────────────────────────────────────┐
│  Buenos días, Javiera. Aquí está el estado a 14/07/2026 09:14              │
├────────────────────────────────────────────────────────────────────────────┤
│  KPIs (fila 1)                                                             │
│  ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐               │
│  │ 218   │ │  4    │ │  7    │ │  2    │ │  3    │ │ 12    │               │
│  │Trabaj.│ │Suspen-│ │Dosim. │ │Dosim. │ │Sin    │ │Autoriz│               │
│  │activos│ │didos  │ │pend.  │ │extra- │ │autor. │ │próx.  │               │
│  │       │ │       │ │devol. │ │viados │ │       │ │vencer │               │
│  └───────┘ └───────┘ └───────┘ └───────┘ └───────┘ └───────┘               │
│                                                                            │
│  KPIs (fila 2)                                                             │
│  ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐ ┌───────┐               │
│  │ 5     │ │ 2     │ │  1    │ │ 8     │ │  4    │ │  3    │               │
│  │Equip. │ │Equip. │ │Blind. │ │QA     │ │Inspec.│ │Incid. │               │
│  │pend.  │ │f. serv│ │pend.  │ │pend.  │ │pend.  │ │abiert.│               │
│  └───────┘ └───────┘ └───────┘ └───────┘ └───────┘ └───────┘               │
├───────────────────────────────┬────────────────────────────────────────────┤
│  Dosis colectiva últimos 12m  │  Vencimientos próximos 90 días             │
│  [barras apiladas por serv.]  │  ▓▓▓▓▓░░░░░░ Autorizaciones (12)          │
│                               │  ▓▓▓░░░░░░░░ Licencias (5)                │
│                               │  ▓▓▓▓▓▓▓░░░░ Calibraciones (18)           │
│                               │  ▓▓░░░░░░░░░ QA (7)                       │
├───────────────────────────────┼────────────────────────────────────────────┤
│  Alertas regulatorias         │  Copilot — Recomendado hoy                 │
│  🔴 Reporte trimestral SEREMI │  • Cerrar incidente #INC-2026-014           │
│     en 3 días                  │  • Reservar cupo curso OPR (2 cupos)       │
│  🟡 Curso obligatorio: 4 pers.│  • Revisar 3 documentos clasificados       │
│  🟡 Residuo I-131 lote #22    │  • Confirmar recepción dosimétrica junio    │
│     lista para disposición     │                                            │
└───────────────────────────────┴────────────────────────────────────────────┘
```

## 9.3 Comportamiento

- Todos los KPIs son **clicables** y llevan a la lista filtrada correspondiente.
- Widgets **arrastrables** (grid `react-grid-layout`).
- Preferencias persistidas por usuario.
- Datos en tiempo real vía SignalR (nuevos incidentes aparecen sin recargar).
- Modo TV/kiosco para muros de control.

## 9.4 Roles y dashboards diferenciados

| Rol | Foco del dashboard |
|-----|--------------------|
| OPR | Operacional, todo lo anterior |
| Director | Ejecutivo, KPIs agregados, tendencias mensuales |
| Trabajador POE | Su dosis, sus autorizaciones, sus tareas |
| Auditor regulador | Cumplimiento por instalación, semáforos |
| Físico médico | QA equipos, blindajes, incidentes técnicos |

---

# 10. APIs y contratos

## 10.1 Filosofía

- **API-first:** cada capacidad se expone como REST antes de tener UI.
- **OpenAPI 3.1** como contrato canónico; SDKs generados (TypeScript, Python, C#, Java).
- **Versionado semántico** por header `Api-Version: 2026-07-14` (fecha-versión estilo Stripe).
- **HATEOAS ligero** en respuestas con `_links`.
- **Idempotencia** por header `Idempotency-Key`.
- **Rate limiting** por token: 600 req/min estándar, sobredimensionable para integraciones.
- **Errores** en formato **RFC 7807 (Problem Details for HTTP APIs)**.

## 10.2 Endpoints núcleo (extracto)

```
# Workers
POST   /v1/workers
GET    /v1/workers/{id}
GET    /v1/workers?service_id=…&status=active&page=1&limit=50
PATCH  /v1/workers/{id}
POST   /v1/workers/{id}:suspend
POST   /v1/workers/{id}:reactivate

# Dosimetry
POST   /v1/dose-readings:bulk-import   (multipart CSV/XLSX/XML)
GET    /v1/workers/{id}/dose-summary?year=2026
GET    /v1/dose-anomalies?since=2026-01-01

# Documents
POST   /v1/documents            (multipart)
GET    /v1/documents/{id}
GET    /v1/documents/{id}/versions
POST   /v1/documents/{id}:sign
GET    /v1/documents/search?q=&type=&expires_before=

# AI / Copilot
POST   /v1/ai/ask
       body: { "question": "…", "scope": { "worker_id": "…" } }
       → SSE stream con tokens + citaciones

POST   /v1/ai/documents:classify
POST   /v1/ai/documents:extract
POST   /v1/ai/reports:draft
       body: { "type": "quarterly_seremi", "period": "2026-Q2" }

# Compliance
GET    /v1/compliance/status
GET    /v1/compliance/calendar?from=&to=
POST   /v1/compliance/reports:generate

# Incidents
POST   /v1/incidents
GET    /v1/incidents/{id}
POST   /v1/incidents/{id}/actions
POST   /v1/incidents/{id}:close

# Equipment
GET    /v1/equipment/{id}
POST   /v1/equipment/{id}/qa-records
GET    /v1/equipment/{id}/documents

# Search universal
GET    /v1/search?q=…&types=worker,equipment,document&limit=20
```

## 10.3 Webhooks

Eventos publicados a URLs registradas por el tenant (firmados HMAC-SHA-256):

```
worker.created
worker.suspended
dose.reading.anomaly_detected
dose.reading.imported
document.classified
document.expired
authorization.expiring_soon
license.expired
incident.reported
incident.severity_updated
audit.finding_created
equipment.qa_failed
```

## 10.4 GraphQL (para dashboard y móvil)

Endpoint `/v1/graphql` con queries agregadas para reducir round-trips:

```graphql
query Dashboard($tenantId: ID!) {
  kpis(tenantId: $tenantId) {
    activeWorkers suspendedWorkers pendingDosimeters
    lostDosimeters unauthorizedWorkers
    upcomingAuthorizations upcomingLicenses
    pendingEquipment outOfServiceEquipment
    pendingShielding pendingQA
    pendingCalibrations pendingInspections
    openIncidents radioactiveWaste regulatoryAlerts
  }
  doseCollectiveLast12m { month totalMSv byService }
  regulatoryAlerts(top: 5) { severity title dueDate url }
  copilotSuggestions(top: 5) { title action deeplink }
}
```

## 10.5 Contratos de integración

- **HL7 FHIR R5** para `Practitioner`, `Device`, `Observation` (dosis paciente si aplica).
- **DICOM** metadata dosis: `RDSR` (Radiation Dose Structured Report) parseado a Timescale.
- **SCIM 2.0** para aprovisionamiento de usuarios desde AD/Entra.
- **CSV/XLSX estándar** con schema publicado para importaciones legacy.

---

# 11. Modelo de permisos y roles

## 11.1 Modelo híbrido RBAC + ABAC + ReBAC

- **RBAC:** roles base predefinidos.
- **ABAC:** atributos (categoría del trabajador, tipo de equipo, servicio, jurisdicción).
- **ReBAC:** relaciones (usuario X es jefe del servicio Y → hereda permisos sobre Y).
- Implementación con **OpenFGA** o **Cerbos** para políticas declarativas.

## 11.2 Roles base

| Rol | Alcance |
|-----|---------|
| **SuperAdmin (Anthropic-side/plataforma)** | Solo staff RPMS |
| **TenantAdmin** | Configuración del tenant, usuarios, integraciones |
| **DirectorPR / Director Médico** | Vista ejecutiva, sin edición operativa |
| **OPR titular** | Todos los módulos operativos del tenant |
| **OPR subrogante** | Igual OPR titular, con marcador |
| **Físico Médico** | Equipos, QA, blindajes, incidentes técnicos |
| **Técnico QA** | Registro de QA y mantenciones |
| **Ingeniero Mantenimiento** | Equipos, incidentes técnicos |
| **Radiofarmaceuta** | Radiofármacos, fuentes, residuos |
| **Auditor Interno** | Read-only + módulo auditorías |
| **Auditor Externo/Regulador** | Portal Regulador, temporal, read-only |
| **Trabajador POE** | Portal personal: su dosis, autorizaciones, capacitaciones |
| **Proveedor Dosimetría** | API restringida para subida de datos |
| **Copilot (system principal)** | Lectura amplia, escrituras siempre confirmadas por humano o marcadas AI |

## 11.3 Ejemplo de política (OpenFGA-like)

```
type worker
  relations
    define viewer as owner or supervisor from service
    define editor as opr from tenant

type service
  relations
    define supervisor as user
    define opr as user from tenant

type document
  relations
    define related_worker as [worker]
    define viewer as viewer from related_worker or role_opr from tenant
```

## 11.4 Elevación temporal y break-glass

- Acceso extraordinario (ej. emergencia radiológica) mediante **workflow de elevación**: aprobado por segundo rol, con expiración, todo auditado.

## 11.5 Auditoría de acciones

- Tabla `audit_log` inmutable con `user_id`, `action`, `entity`, `entity_id`, `before/after (JSONB)`, `ip`, `user_agent`, `session_id`, `tenant_id`.
- Reglas SIEM que detectan patrones sospechosos (descarga masiva, acceso fuera de horario, cambios en dosimetría histórica).

---

# 12. Estrategia de IA y automatización

## 12.1 Principios de IA responsable

1. **Human-in-the-loop obligatorio** en escrituras de datos regulados (dosimetría, autorizaciones, incidentes).
2. **Explicabilidad:** cada respuesta del Copilot cita fuentes internas (documentos, tablas, entidades).
3. **Determinismo relativo:** temperatura baja (0.1–0.3) para tareas regulatorias; alta solo en redacción creativa.
4. **PII protegida:** enmascaramiento antes de enviar a LLM externo; opción de LLM local para datos sensibles.
5. **Guardrails:** validación JSON schema en salidas estructuradas; rechazo si no valida.
6. **Registro completo:** prompt + respuesta + tokens + costo por interacción, con opción de opt-out del usuario.

## 12.2 Arquitectura RAG multi-etapa

```
Pregunta del usuario
   │
   ▼
[Reescritura de consulta]  (LLM barato: descompone, expande sinónimos técnicos)
   │
   ▼
[Recuperación híbrida]
   ├─ BM25 (OpenSearch) top 50
   ├─ Vector (pgvector) top 50
   └─ Grafo (KnowledgeEdge) top 20  ← navega entidades relacionadas
   │
   ▼
[Fusión + Reranker] Cohere Rerank / bge-reranker → top 8
   │
   ▼
[Composición de contexto]
   ├─ Snippets citados con document_id, page, bbox
   ├─ Metadatos estructurados (fechas, IDs)
   └─ Herramientas invocables (funciones SQL parametrizadas seguras)
   │
   ▼
[LLM principal]  Claude Sonnet / Opus (según complejidad)
   │
   ▼
[Validación de salida]
   ├─ JSON schema (si estructurado)
   ├─ Verificación de citas (no alucinar fuentes)
   └─ Filtro de compliance (no incluir PII no autorizada)
   │
   ▼
Respuesta con citas y "acciones sugeridas" clicables
```

## 12.3 Agentes especializados

| Agente | Función | Autonomía |
|--------|---------|-----------|
| **DocIngestAgent** | OCR + clasificación + NER + vinculación | Alta (validación humana batch) |
| **DosimetryAnomalyAgent** | Detecta anomalías, propone hipótesis | Media (alerta, no cierra) |
| **ComplianceAgent** | Evalúa reglas y genera calendario legal | Alta |
| **ReportDraftingAgent** | Genera borradores de reportes regulatorios | Baja (siempre requiere firma humana) |
| **AuditAgent** | Sugiere hallazgos y acciones a partir de datos | Media |
| **KnowledgeGraphAgent** | Descubre nuevas relaciones entre entidades | Media |

Todos coordinados por un **AI Orchestrator** basado en **LangGraph**, con estado persistido y trazas completas.

## 12.4 Automatizaciones no-IA (reglas puras)

- Recordatorios 90/60/30/15/7/1 día → cron jobs generan tareas y notificaciones multi-canal.
- Auto-decaimiento de fuentes radiactivas (fórmula A(t) = A₀ e^(−λt)) → job diario.
- Reconciliación de dosímetros: entregados vs. devueltos, alerta si >30 días sin devolver.
- Cierre automático de tareas cuando el evento subyacente se resuelve.

## 12.5 Aprendizaje continuo

- Cada corrección humana del OCR/NER se guarda como *labeled data*.
- Job semanal genera reporte de calidad y activa fine-tune si degradación.
- Feedback "👍/👎" en respuestas del Copilot → RLHF ligero interno.

## 12.6 Costos de IA (control)

- Presupuesto por tenant configurable.
- Router de modelos: preguntas simples → modelo barato/local; complejas → modelo top.
- Cache semántico (Redis) para preguntas frecuentes.
- Batch nocturno para reprocesamiento de documentos históricos.

---

# 13. Plan de desarrollo por fases

## 13.1 Estrategia general

- **Producto:** MVP en 4 meses, versión comercial en 8 meses, versión enterprise en 14 meses.
- **Equipo mínimo viable:** 12 personas (2 PM, 3 backend, 2 frontend, 1 IA, 1 DevOps, 1 QA, 1 UX, 1 OPR consultor).
- **Metodología:** Shape Up (ciclos de 6 semanas) + operación continua.
- **Feature flags** desde el día 1 (Unleash o LaunchDarkly).

## 13.2 Fase 0 — Fundaciones (mes 0–1)

- Setup mono-repo (Nx o Turborepo).
- IaC base (Terraform: VPC, EKS/AKS, RDS PostgreSQL, S3, Redis, OpenSearch).
- Pipeline CI/CD con security scans (Snyk, Trivy, Dependabot).
- Keycloak + primer login.
- Design system base (tokens + 20 componentes).
- Skeleton de 12 microservicios con healthcheck.
- Observabilidad end-to-end.

## 13.3 Fase 1 — MVP (mes 2–4)

**Objetivo:** un hospital piloto puede reemplazar sus Excel de OPR.

Incluye:
- Trabajadores (ficha, autorizaciones, licencias, capacitaciones).
- Equipos (inventario básico).
- Dosimetría (importación manual XLSX, historial, alertas simples).
- Documentos (upload, OCR básico Tesseract, clasificación LLM, búsqueda full-text).
- Dashboard con 12 KPIs.
- Reportes PDF básicos.
- Notificaciones email.
- Copilot v0: Q&A sobre documentos.
- Auditoría de acciones.

Éxito medible: **90 % del trabajo diario del OPR** cubierto sin Excel.

## 13.4 Fase 2 — Producto comercial (mes 5–8)

Incluye:
- Ingesta dosimétrica automática (2 proveedores).
- Motor de reglas regulatorio Chile completo.
- Incidentes con flujo completo.
- Blindajes con planos y fotos.
- Medicina nuclear (fuentes, radiofármacos, residuos).
- Instrumentación completa.
- Auditorías internas.
- Reportes regulatorios chilenos (5 formularios oficiales).
- Copilot v1: agentes especializados + redacción.
- Mobile app v1 (inspecciones offline).
- Portal del trabajador.
- Integraciones HL7 FHIR + AD/Entra.

## 13.5 Fase 3 — Enterprise (mes 9–14)

Incluye:
- Multi-jurisdicción (Argentina, Perú, Colombia, México).
- Portal Regulador.
- Marketplace de integraciones.
- Grafo de conocimiento avanzado (Neo4j/AGE).
- IA visual para blindajes.
- Predictor de sobreexposición ML.
- Data warehouse + BI embebido.
- SLA 99.95%.
- Cumplimiento SOC 2 Type II + ISO 27001 certificados.

## 13.6 Fase 4 — Consolidación regional (mes 15–20)

- Certificación FDA/CE en módulos donde aplique.
- Ecosistema de partners (integradores, distribuidores).
- Programa académico (universidades usan RPMS para docencia gratis).
- AI Copilot con voz.
- Realidad aumentada para inspecciones (visor de blindajes en obra).

---

# 14. Estrategia de pruebas y validación

## 14.1 Pirámide de pruebas

```
                     ┌──────────┐
                     │  E2E     │  10 %  Playwright
                     └──────────┘
                  ┌────────────────┐
                  │  Integración   │  25 %  Testcontainers
                  └────────────────┘
             ┌──────────────────────────┐
             │       Unitarias           │  55 %  Vitest / xUnit / pytest
             └──────────────────────────┘
        ┌─────────────────────────────────────┐
        │  Contract / Consumer-Driven         │  10 %  Pact
        └─────────────────────────────────────┘
```

## 14.2 Tipos de pruebas específicas

| Tipo | Herramientas | Cobertura mínima |
|------|--------------|------------------|
| Unitarias | xUnit (.NET), pytest, Vitest | 80 % líneas críticas |
| Integración | Testcontainers (Postgres, Kafka, Redis) | Todos los adaptadores |
| API contract | Pact broker | 100 % endpoints públicos |
| E2E | Playwright + POM | 30 flujos críticos |
| Carga | k6 | Objetivo P95 documentado |
| Seguridad estática | Snyk, SonarQube, Semgrep | En cada PR |
| Seguridad dinámica | OWASP ZAP | Nightly |
| Pentest externo | Empresa acreditada | Semestral |
| IA — regression | Golden set 500 documentos etiquetados | Cada release |
| IA — hallucination | Evaluador LLM + benchmark propio | Cada release |
| Accesibilidad | axe-core + revisión manual | WCAG 2.2 AA |
| Performance frontend | Lighthouse CI | LCP <2.5s, CLS <0.1 |
| Chaos engineering | Chaos Mesh | Producción semanal |

## 14.3 Validación con OPRs reales

- **Alfa cerrada:** 3 hospitales piloto usan gratis por 6 meses.
- **Encuesta NPS mensual** más entrevistas con OPRs.
- **Shadow OPR:** un OPR senior en el equipo revisa flujos críticos cada sprint.

## 14.4 Validación regulatoria

- Revisión legal de las plantillas de reportes con abogado especialista y con la SEREMI si es posible.
- Simulacros de fiscalización con el sistema en modo Portal Regulador.

## 14.5 Datos sintéticos y anonimización

- Set de datos sintéticos por sector (radioterapia, medicina nuclear, industrial) para pruebas y demos.
- Herramienta de anonimización para importar datos reales de clientes en ambiente de staging.

---

# 15. Estrategia de despliegue y mantenimiento

## 15.1 Modelos de despliegue

| Modelo | Público objetivo | Nota |
|--------|-----------------|------|
| **SaaS multitenant** (default) | Clínicas, centros PET, universidades | Menor costo, actualizaciones continuas |
| **SaaS single-tenant** | Hospitales grandes, industria | Aislamiento total, mismo código |
| **On-premises** | Hospitales públicos, reguladores | Empaquetado Kubernetes + Helm |
| **Sovereign cloud** | Reguladores nacionales | Región dedicada país |

## 15.2 CI/CD

```
git push
   │
   ▼
[Lint · Type check · Unit tests]      ~3 min
   │
   ▼
[Build container · SBOM · scan vulnerab.]  ~5 min
   │
   ▼
[Test integración con Testcontainers]  ~8 min
   │
   ▼
[Push a registry firmado (cosign)]
   │
   ▼
[ArgoCD sync a env dev]
   │
   ▼ (manual approval)
[Promote a staging] → smoke tests → E2E
   │
   ▼ (manual approval por producto)
[Promote a prod]
   ├─ Blue/green o canary 5% → 25% → 50% → 100%
   └─ Rollback automático si SLO error > 1% en 3 min
```

## 15.3 Observabilidad y alerting

- **RED metrics** (Rate, Errors, Duration) por endpoint.
- **USE metrics** (Utilization, Saturation, Errors) por servicio.
- **SLO error budget** trackeado en Grafana con burn-rate alerts.
- **Alerting** en PagerDuty/Opsgenie con on-call rotativo.
- **Runbooks** en Notion/Backstage vinculados a cada alerta.

## 15.4 Gestión de vulnerabilidades

- SLA de parches:
  - Critical (CVSS ≥ 9): 24 h.
  - High (7–8.9): 7 días.
  - Medium (4–6.9): 30 días.
- Dependabot + Renovate.
- Bug bounty (fase enterprise).

## 15.5 Backups y DR (repetición operacional)

- Backups automáticos con verificación de restore trimestral y auditoría del reporte.
- DRP documentado con RTO ≤ 30 min y RPO ≤ 5 min.
- Ejercicio anual de failover completo.

## 15.6 Gestión del ciclo de vida de datos

- Retención dosimétrica: 30 años (obligación legal en muchas jurisdicciones).
- Retención documental oficial: 10 años mínimo (o lo que exija la norma local).
- **Derecho al olvido** para PII no regulatoria: 6 meses tras baja.
- Exportación de datos al cliente en formato abierto (Parquet + JSON + PDF).

## 15.7 Soporte al cliente

- 3 niveles (L1 chat, L2 experto, L3 ingeniería).
- Health score por tenant (indicador proactivo de churn).
- Customer Success con OPR-in-residence (persona con experiencia real).
- Base de conocimiento pública + academia en línea.

---

# 16. Recomendaciones para convertirlo en referente internacional

## 16.1 Producto

1. **Publicar un estándar abierto de interoperabilidad de dosimetría** ("Open Dosimetry Exchange") — CSV/JSON schema + validador. Convertirse en el "Stripe API" de la industria dosimétrica.
2. **Certificaciones tempranas:** ISO 27001, SOC 2 Type II, HIPAA (mercado latino cada vez lo exige aunque no sea obligatorio).
3. **Módulo académico gratuito** para universidades → generas talento formado en la plataforma.
4. **Certificación oficial "RPMS Certified OPR"** — programa de capacitación que aumenta empleabilidad y bloquea competencia.
5. **Community edition** con núcleo open-source (identidad + workers + documentos básicos) → adopción viral + confianza.

## 16.2 Ecosistema

6. **API pública documentada como Stripe** — sample apps, SDKs, Postman collection, sandbox.
7. **Marketplace de integraciones** monetizado (proveedores dosimétricos pagan por listado premium).
8. **Programa de partners** (integradores locales por país).

## 16.3 Presencia y credibilidad

9. **Consejo asesor regulatorio** con miembros de OIEA, ICRP, autoridades locales.
10. **Whitepapers técnicos** trimestrales con casos reales (anonimizados).
11. **Conferencia anual** en Santiago con streaming y patrocinios.
12. **Publicaciones científicas** conjuntas con clientes en revistas de física médica.

## 16.4 Excelencia operativa

13. **Status page pública** (status.rpms.app) con transparencia radical.
14. **Postmortems públicos** de incidentes serios (cultura de aprendizaje).
15. **Trust center** con documentación de seguridad, certificados, DPAs.

## 16.5 IA como ventaja duradera

16. **Colección propietaria de documentos regulatorios latinoamericanos** — barrera de entrada.
17. **Modelo fine-tuned de clasificación documental protección radiológica** — patentable/registrable.
18. **Benchmark abierto** de calidad de OCR/NER en documentos regulatorios — se convierte en el estándar de la industria.

## 16.6 Estrategia comercial

19. **Freemium para prácticas pequeñas** (odontología, veterinaria) → funnel enorme, upsell a hospital.
20. **Pricing por camas/POE/equipos**, no por usuario (alinea con impacto real).
21. **Land & expand:** entrar por dosimetría (dolor claro) y expandir al resto.

## 16.7 Preparación para el largo plazo (15–20 años)

- **Arquitectura orientada a eventos** desde el día uno → refactorización a AI-native más simple.
- **Contratos versionados con retro-compatibilidad de al menos 3 años.**
- **Talent flywheel:** contratar juniors, capacitar, retener.
- **Documentación arquitectónica viva** (ADRs en repo, C4 actualizado).
- **Presupuesto de innovación:** 15 % del roadmap para experimentación no-obvia.

---

# 17. Anexos regulatorios

## 17.1 Normativa chilena base (implementación módulo compliance-CL)

- **DS N° 133/1984** — Reglamento sobre autorizaciones para instalaciones radiactivas o equipos generadores de radiaciones ionizantes.
- **DS N° 3/1985** — Reglamento de protección radiológica de instalaciones radiactivas.
- **Código Sanitario** (Libro Sexto).
- **Ley N° 18.302** — Ley de Seguridad Nuclear (CCHEN).
- **DS N° 594/1999** — Condiciones sanitarias y ambientales básicas en los lugares de trabajo.
- Resoluciones específicas del **ISP** para dosimetría.
- **Guías MINSAL** y protocolos SEREMI.

**Nota:** las normativas se actualizan y algunas están en revisión (por ejemplo, propuestas de modernización del DS 3/1985 y DS 133/1984 discutidas los últimos años). El motor de reglas debe versionar cada norma con `valid_from` / `valid_to` y permitir "reglas propuestas" en modo simulación. Antes del despliegue en producción, cada regla debe validarse con un OPR local y, cuando sea posible, con la propia autoridad.

## 17.2 Estándares internacionales de referencia

- **ICRP 60, 103** — recomendaciones límites de dosis.
- **ICRP 118** — reacciones tisulares cristalino.
- **IAEA GSR Part 3** — Radiation Protection and Safety of Radiation Sources.
- **IAEA SSG-46** — Radiation Protection and Safety in Medical Uses of Ionizing Radiation.
- **IAEA Safety Reports Series** — específicos por modalidad.
- **NCRP 147/151** — blindajes.

## 17.3 Escala INES (International Nuclear Event Scale)

- Nivel 0 (desviación) a Nivel 7 (accidente mayor).
- El módulo de incidentes tiene wizard guiado para clasificación INES.

## 17.4 Interfaces obligatorias

- Reporte de dosis efectiva anual por trabajador (Hp(10), Hp(0.07), Hp(3)).
- Inventario de fuentes con isótopo, actividad, ubicación.
- Registro de incidentes por tipo y severidad.
- Registro de capacitaciones y competencias.

---

# Cierre

Este documento es la **versión 1.0 del blueprint**. Se recomienda:

1. Revisar con OPR titular del hospital patrocinador antes de iterar.
2. Priorizar decisiones abiertas (proveedor cloud principal, LLM primario, modelo comercial) en un ADR (Architecture Decision Record) por decisión.
3. Iniciar Fase 0 con equipo de 6 personas y plan de contratación a 12 en tres meses.
4. Ejecutar un **discovery de 2 semanas** en un hospital piloto para validar 20 supuestos operativos antes de escribir código de dominio.

Cualquier apartado (por ejemplo, ERD detallado con todas las tablas, wireframes en Figma, especificación OpenAPI completa, ADRs específicos, contratos comerciales, prompts de sistema del Copilot, o plan detallado de contratación) puede desarrollarse como un documento hijo.

