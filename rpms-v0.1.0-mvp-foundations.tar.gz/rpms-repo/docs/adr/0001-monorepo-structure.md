# ADR-0001: Monorepo con carpetas por dominio

- **Estado:** Aceptado
- **Fecha:** 2026-07-14
- **Deciders:** Comité de arquitectura RPMS

## Contexto

RPMS se compone de múltiples servicios (workforce, dosimetry, document,
compliance, etc.) que evolucionan a distinta velocidad pero comparten:

- Contratos de datos (Worker, Document, Equipment).
- Librería de tipos y utilidades (`rpms-core`).
- Estilo, linting, y pipelines de CI.
- Documentación arquitectónica y regulatoria.

## Decisión

Adoptar un **monorepo** con carpetas por dominio:

- `services/` — un microservicio por carpeta, autónomo, con su propio
  `pyproject.toml`, tests y Dockerfile.
- `libs/` — librerías internas versionadas semánticamente.
- `frontend/` — apps de UI.
- `db/` — migraciones y semillas transversales.
- `docs/`, `infra/`, `scripts/`, `tests/` — soporte.

Cada servicio expone su API por OpenAPI. La comunicación es por eventos
(Kafka) y REST/gRPC.

## Consecuencias positivas

- Refactors cross-service atómicos.
- Un solo `CODEOWNERS` claro.
- Fácil compartir tipos y contratos.
- CI unificado con caché y matrices.

## Consecuencias negativas

- Requiere herramientas de builds selectivos (Nx, Turborepo, o make + git-diff).
- Permisos de repositorio menos granulares que multi-repo.

## Alternativas descartadas

- **Multi-repo:** overhead de sincronización de contratos y versiones.
- **Repo por capa (front/back separados):** dificulta refactors de dominio.
