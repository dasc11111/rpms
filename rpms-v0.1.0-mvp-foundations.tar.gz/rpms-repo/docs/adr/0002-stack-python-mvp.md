# ADR-0002: Stack Python + FastAPI para servicios de dominio (MVP)

- **Estado:** Aceptado (revisable en Fase 3)
- **Fecha:** 2026-07-14
- **Deciders:** Comité de arquitectura RPMS

## Contexto

El blueprint permitía dos alternativas para el backend de dominio:
**.NET 9** o **Python + FastAPI**. Ambas cumplen los requisitos técnicos.

## Decisión

Adoptar **Python 3.12 + FastAPI + SQLAlchemy 2 + Pydantic v2** para todos
los servicios de dominio del MVP y de la versión comercial.

## Justificación

1. **Coherencia con la capa IA:** todos los pipelines de OCR, NER, RAG,
   agentes y ML corren en Python. Un único runtime reduce fricción y coste
   cognitivo del equipo.
2. **Ecosistema científico:** protección radiológica es una disciplina
   numérica (dosimetría, decaimiento, cálculos ICRP); numpy/pandas/scikit
   son de primera clase en Python.
3. **Velocidad de iteración:** FastAPI + Pydantic ofrecen contratos OpenAPI
   automáticos, validaciones tipadas, y menor boilerplate que .NET para el
   volumen de servicios previsto.
4. **Talento LatAm:** el mercado latinoamericano tiene mayor densidad de
   ingenieros Python senior que .NET senior con experiencia en microservicios.

## Consecuencias positivas

- Un único lenguaje backend → menos duplicación de utilidades.
- Reutilización de modelos ML directamente en dominio (feature flags).
- Deploy más sencillo (imágenes más pequeñas si se optimizan).

## Consecuencias negativas

- Rendimiento por request menor que .NET en cargas CPU-bound.
  → **Mitigación:** cargas críticas usan `uvicorn` con múltiples workers +
  `asyncio` en I/O; para hot paths se puede introducir Rust vía PyO3.
- GIL en workflows multi-thread.
  → **Mitigación:** procesos separados, workers con Celery/Arq.

## Revisión

Reevaluar en Fase 3 si algún servicio (típicamente dosimetry en cargas
masivas de importación) requiere reescritura en Rust o .NET.
