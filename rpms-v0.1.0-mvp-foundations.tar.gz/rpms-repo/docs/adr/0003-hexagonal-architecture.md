# ADR-0003: Arquitectura hexagonal (Ports & Adapters) por servicio

- **Estado:** Aceptado
- **Fecha:** 2026-07-14
- **Deciders:** Comité de arquitectura RPMS

## Contexto

Los servicios de RPMS deben:

- Aislar la lógica de dominio de la infraestructura (BD, HTTP, colas).
- Ser testables sin infraestructura externa.
- Sobrevivir a cambios de tecnología (por ejemplo, migrar de PostgreSQL a
  otro RDBMS, o de REST a gRPC) sin reescribir dominio.
- Facilitar el uso de eventos de dominio y CQRS ligero.

## Decisión

Cada servicio sigue **arquitectura hexagonal (Ports & Adapters)** con
cuatro capas:

```
service-svc/
└── src/
    ├── domain/          # Entities, Value Objects, Domain Events, Invariants
    ├── application/     # Commands, Queries, Handlers, Ports (interfaces)
    ├── infrastructure/  # Adapters: SQL, S3, Kafka, HTTP clients
    └── api/             # Adapters de entrada: FastAPI routers, schemas
```

Reglas:

1. `domain/` no importa de ninguna otra capa (puro).
2. `application/` sólo importa de `domain/`.
3. `infrastructure/` implementa las interfaces (ports) definidas en
   `application/`.
4. `api/` traduce entre HTTP y comandos/queries de `application/`.
5. La composición se hace en un `container` (dependency injection) en el
   entrypoint (`main.py`).

## Consecuencias positivas

- Tests de dominio 100 % en memoria sin fixtures pesados.
- Reemplazar adaptadores es local (por ejemplo, SQLite en tests, Postgres
  en producción).
- Consistencia entre servicios facilita rotación de equipos.

## Consecuencias negativas

- Curva de aprendizaje inicial.
- Ligero overhead de código (interfaces + implementaciones).

## Referencias

- Alistair Cockburn, *Hexagonal Architecture* (2005).
- Vaughn Vernon, *Implementing Domain-Driven Design*.
