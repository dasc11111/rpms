# Guía de arranque — RPMS v0.1.0

## Prerrequisitos

**Mínimo para explorar el código y ejecutar tests:**
- Python 3.12+
- sqlite3 (viene con Python)
- Git

**Para levantar todo el stack (Docker Compose):**
- Docker 24+ y Docker Compose v2
- 8 GB RAM libres (PostgreSQL + OpenSearch consumen la mayoría)
- 20 GB de espacio en disco

**Para ejecutar el frontend Next.js localmente:**
- Node.js 20+
- pnpm 9 o npm

## Camino 1 — Solo backend Python (sandbox sin red)

Esta es la forma más rápida de validar que todo funciona.

```bash
# Clonar y entrar
git clone <repo-url> rpms
cd rpms

# Ejecutar la suite completa
make check-sandbox

# Salida esperada:
#   Tests totales: 129
#   Fallos: 0
#   Errores: 0
```

Explorar cada servicio:

```bash
# Ver estructura de un servicio con arquitectura hexagonal completa
tree services/workforce-svc/src -L 3

# Ejecutar solo un archivo de tests
python3 services/workforce-svc/tests/test_domain.py
python3 services/dosimetry-svc/tests/test_domain.py
python3 services/compliance-svc/tests/test_rules.py
python3 services/document-svc/tests/test_pipeline.py
```

Inspeccionar la base de datos SQLite generada:

```bash
sqlite3 /tmp/rpms_dev.sqlite
sqlite> .tables
sqlite> SELECT full_name, icrp_category, status FROM worker;
sqlite> SELECT count(*) FROM dose_reading;
```

## Camino 2 — Stack completo con Docker Compose

Requiere red y ~8 GB RAM.

```bash
# 1. Levantar todo
cd infra/docker
docker compose up -d

# 2. Verificar que todos los servicios estén healthy
docker compose ps

# 3. Aplicar migraciones a PostgreSQL
docker compose exec workforce-svc python /app/db/scripts/apply_migrations.py

# 4. Cargar datos de demo
docker compose exec workforce-svc python /app/db/scripts/seed.py

# 5. Abrir el frontend
open http://localhost:3000
```

## Camino 3 — Solo el frontend

Requiere red para `pnpm install`.

```bash
cd frontend/web
pnpm install
pnpm dev
# → http://localhost:3000
```

El frontend funciona con datos mock si no hay backend disponible.

## Rutas útiles después de levantar el stack

| URL | Descripción |
|-----|-------------|
| http://localhost:3000 | Aplicación web (dashboard) |
| http://localhost:3000/workers | Lista de trabajadores |
| http://localhost:3000/workers/w-1 | Ficha del trabajador Javiera Muñoz |
| http://localhost:8001/docs | API workforce-svc (Swagger UI) |
| http://localhost:8080 | Consola Keycloak (admin/admin) |
| http://localhost:9001 | Consola MinIO (rpms_admin/rpms_dev_password) |
| http://localhost:9090 | Prometheus |
| http://localhost:3001 | Grafana (admin/admin) |

## Comandos frecuentes

```bash
make check-sandbox     # Suite completa de tests
make db-init          # Aplicar migraciones a SQLite dev
make db-seed          # Cargar seed de demo
make db-reset         # Limpiar y volver a inicializar

# Docker
docker compose up -d workforce-svc      # Solo un servicio
docker compose logs -f document-svc     # Ver logs en tiempo real
docker compose down -v                  # Limpiar todo (incl. volúmenes)

# Frontend
cd frontend/web && pnpm typecheck       # Verificación de tipos
cd frontend/web && pnpm build           # Build de producción
```

## Solución de problemas

**"pytest not found" al correr tests:**
No usamos pytest en el sandbox. Usamos el runner nativo:
```bash
python3 scripts/run_all_tests.py
```

**PostgreSQL en docker-compose no arranca:**
Timescale requiere más recursos. Verificar con:
```bash
docker compose logs postgres
```
Si falla por memoria, subir a 4 GB dedicados en la config de Docker Desktop.

**"ModuleNotFoundError: rpms_core":**
Añadir el path al PYTHONPATH:
```bash
export PYTHONPATH=$PYTHONPATH:$(pwd)/libs/rpms-core
```

**Tests de dosimetry fallan por sklearn:**
```bash
pip install scikit-learn --break-system-packages   # o dentro de un venv
```

## Contactos

- Blueprint arquitectónico: `docs/architecture/RPMS_Arquitectura_Completa.md`
- Estado y roadmap: `README.md`
- ADRs (decisiones arquitectónicas): `docs/adr/`
