#!/usr/bin/env python3
"""Runner unificado de tests del monorepo (sin dependencia de pytest).

Descubre y ejecuta todos los `tests/test_*.py` de cada servicio y librería,
sumando resultados y exit code apropiado.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

TEST_DIRS = [
    ROOT / "libs" / "rpms-core" / "tests",
    ROOT / "services" / "workforce-svc" / "tests",
    ROOT / "services" / "document-svc" / "tests",
    ROOT / "services" / "dosimetry-svc" / "tests",
    ROOT / "services" / "compliance-svc" / "tests",
]


def discover(tests_dir: Path) -> list[Path]:
    if not tests_dir.exists():
        return []
    return sorted(tests_dir.glob("test_*.py"))


def run_test_file(path: Path) -> tuple[int, int, int]:
    """Ejecuta un archivo de test y devuelve (ran, failed, errors)."""
    result = subprocess.run(
        [sys.executable, str(path)],
        capture_output=True,
        text=True,
        cwd=str(ROOT),
    )
    # unittest reporta en stderr: "Ran N tests in ...s"
    out = result.stderr + result.stdout
    # Buscar líneas de resumen
    ran = failed = errors = 0
    for line in out.splitlines():
        if line.startswith("Ran ") and " test" in line:
            try:
                ran = int(line.split()[1])
            except (IndexError, ValueError):
                pass
        if line.startswith("FAILED"):
            # FAILED (failures=X, errors=Y)
            import re
            fm = re.search(r"failures=(\d+)", line)
            em = re.search(r"errors=(\d+)", line)
            failed = int(fm.group(1)) if fm else 0
            errors = int(em.group(1)) if em else 0
    if result.returncode != 0 and failed == 0 and errors == 0:
        # Falla de import u otra
        errors = 1
        print(f"\n  ERROR ejecutando {path.name}:")
        print("  " + "\n  ".join((out or "sin salida").splitlines()[-10:]))
    return ran, failed, errors


def main() -> int:
    total_ran = total_failed = total_errors = 0
    files_run = 0
    print("=" * 70)
    print("RPMS — Suite de tests del monorepo")
    print("=" * 70)
    for d in TEST_DIRS:
        files = discover(d)
        if not files:
            continue
        for f in files:
            rel = f.relative_to(ROOT)
            ran, failed, errors = run_test_file(f)
            files_run += 1
            total_ran += ran
            total_failed += failed
            total_errors += errors
            status = "OK" if (failed == 0 and errors == 0) else "FAIL"
            print(f"  [{status}] {rel}  ({ran} tests)")
    print("=" * 70)
    print(f"Archivos ejecutados: {files_run}")
    print(f"Tests totales:       {total_ran}")
    print(f"Fallos:              {total_failed}")
    print(f"Errores:             {total_errors}")
    print("=" * 70)
    return 0 if (total_failed == 0 and total_errors == 0) else 1


if __name__ == "__main__":
    sys.exit(main())
